package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.repository.EstivasRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class EstivasApplication : Application() {
    val applicationScope = CoroutineScope(SupervisorJob())

    val database by lazy { AppDatabase.getDatabase(this, applicationScope) }
    val repository by lazy { EstivasRepository(database.appDao()) }
}
