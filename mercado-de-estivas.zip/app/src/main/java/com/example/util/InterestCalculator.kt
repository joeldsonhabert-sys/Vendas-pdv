package com.example.util

import java.util.Calendar
import java.util.concurrent.TimeUnit
import kotlin.math.max

data class InterestCalculationResult(
    val valorOriginal: Double,
    val valorPago: Double,
    val saldoDevedorBase: Double,
    val dataVencimento: Long,
    val diasAtraso: Long,
    val jurosMensalPercentual: Double,
    val valorJuros: Double,
    val valorTotalAtualizado: Double,
    val estaEmAtraso: Boolean
)

object InterestCalculator {

    /**
     * Calculates the due date for "Pagar no fim do mês" given a purchase date and configured closing day.
     * If diaFechamento is >= 28, it sets to the last actual day of that month.
     */
    fun calculateEndOfMonthDueDate(purchaseDateTimestamp: Long, closingDay: Int = 30): Long {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = purchaseDateTimestamp

        val maxDaysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH)
        val targetDay = minOf(closingDay, maxDaysInMonth)

        calendar.set(Calendar.DAY_OF_MONTH, targetDay)
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        calendar.set(Calendar.MILLISECOND, 999)

        return calendar.timeInMillis
    }

    /**
     * Calculates overdue interest for a sale based on financial parameters.
     */
    fun calculateOverdueInterest(
        valorFinal: Double,
        valorPago: Double,
        dataVencimento: Long?,
        jurosMensalPercentual: Double,
        currentTimestamp: Long = System.currentTimeMillis()
    ): InterestCalculationResult {
        val saldoBase = max(0.0, valorFinal - valorPago)
        val dueDate = dataVencimento ?: currentTimestamp

        val isOverdue = currentTimestamp > dueDate && saldoBase > 0.01
        val diffMillis = if (isOverdue) currentTimestamp - dueDate else 0L
        val diasAtraso = TimeUnit.MILLISECONDS.toDays(diffMillis)

        val valorJuros = if (isOverdue && diasAtraso > 0) {
            // Juros de mora pro-rata dia baseado na taxa mensal inserida pelo financeiro
            val taxaDiaria = (jurosMensalPercentual / 100.0) / 30.0
            saldoBase * (taxaDiaria * diasAtraso)
        } else {
            0.0
        }

        val totalAtualizado = saldoBase + valorJuros

        return InterestCalculationResult(
            valorOriginal = valorFinal,
            valorPago = valorPago,
            saldoDevedorBase = saldoBase,
            dataVencimento = dueDate,
            diasAtraso = diasAtraso,
            jurosMensalPercentual = jurosMensalPercentual,
            valorJuros = valorJuros,
            valorTotalAtualizado = totalAtualizado,
            estaEmAtraso = isOverdue
        )
    }
}
