package com.example.util

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Formatters {
    private val ptBrLocale = Locale("pt", "BR")
    private val currencyFormat = NumberFormat.getCurrencyInstance(ptBrLocale)
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", ptBrLocale)
    private val dateTimeFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", ptBrLocale)
    private val monthYearFormat = SimpleDateFormat("MMMM 'de' yyyy", ptBrLocale)

    fun formatCurrency(value: Double): String {
        return currencyFormat.format(value)
    }

    fun formatDate(timestamp: Long?): String {
        if (timestamp == null || timestamp == 0L) return "-"
        return dateFormat.format(Date(timestamp))
    }

    fun formatDateTime(timestamp: Long?): String {
        if (timestamp == null || timestamp == 0L) return "-"
        return dateTimeFormat.format(Date(timestamp))
    }

    fun formatMonthYear(timestamp: Long?): String {
        if (timestamp == null || timestamp == 0L) return "-"
        return monthYearFormat.format(Date(timestamp)).replaceFirstChar { it.uppercase() }
    }

    fun formatCpf(cpf: String): String {
        val digits = cpf.filter { it.isDigit() }
        if (digits.length != 11) return cpf
        return "${digits.substring(0, 3)}.${digits.substring(3, 6)}.${digits.substring(6, 9)}-${digits.substring(9, 11)}"
    }

    fun sanitizeCpf(cpf: String): String {
        return cpf.filter { it.isDigit() }
    }

    fun formatCnpj(cnpj: String): String {
        val digits = cnpj.filter { it.isDigit() }
        if (digits.length != 14) return cnpj
        return "${digits.substring(0, 2)}.${digits.substring(2, 5)}.${digits.substring(5, 8)}/${digits.substring(8, 12)}-${digits.substring(12, 14)}"
    }

    fun formatPhone(phone: String): String {
        val digits = phone.filter { it.isDigit() }
        return when (digits.length) {
            11 -> "(${digits.substring(0, 2)}) ${digits.substring(2, 7)}-${digits.substring(7, 11)}"
            10 -> "(${digits.substring(0, 2)}) ${digits.substring(2, 6)}-${digits.substring(6, 10)}"
            else -> phone
        }
    }
}
