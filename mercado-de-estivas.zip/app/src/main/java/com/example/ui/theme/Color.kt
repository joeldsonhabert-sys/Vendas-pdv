package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Emerald80 = Color(0xFFA7F3D0)
val Amber80 = Color(0xFFFDE68A)
val Slate80 = Color(0xFFCBD5E1)

val Emerald40 = Color(0xFF0F766E)
val Amber40 = Color(0xFFD97706)
val Slate40 = Color(0xFF334155)

val ForestGreen = Color(0xFF1B4D3E)
val ForestGreenLight = Color(0xFFE6F4EA)
val WarmAmber = Color(0xFFD97706)
val AmberLight = Color(0xFFFEF3C7)
val DeepNavy = Color(0xFF0F172A)

val AlertRed = Color(0xFFDC2626)
val AlertRedLight = Color(0xFFFEE2E2)
val WarningOrange = Color(0xFFEA580C)
val WarningOrangeLight = Color(0xFFFFEDD5)
val SuccessGreen = Color(0xFF16A34A)
val SuccessGreenLight = Color(0xFFDCFCE7)

val DarkSurface = Color(0xFF131D19)
val DarkBackground = Color(0xFF0A100E)
val DarkCard = Color(0xFF1C2B25)

val LightBackground = Color(0xFFF7FAF8)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFF0F6F2)

