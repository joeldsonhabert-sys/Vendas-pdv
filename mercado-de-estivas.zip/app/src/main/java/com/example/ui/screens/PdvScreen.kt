package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.Customer
import com.example.data.local.FormaPagamento
import com.example.data.local.Product
import com.example.ui.EstivasViewModel
import com.example.ui.components.BarcodeCameraScannerDialog
import com.example.ui.components.ReceiptSignAndConfirmDialog
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.WarmAmber
import com.example.ui.theme.AmberLight
import com.example.util.Formatters
import com.example.util.InterestCalculator

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdvScreen(
    viewModel: EstivasViewModel,
    onSaleFinished: () -> Unit
) {
    val context = LocalContext.current
    val products by viewModel.products.collectAsStateWithLifecycle()
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val company by viewModel.companyProfile.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val selectedCustomer by viewModel.selectedCustomer.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var selectedPaymentMethod by remember { mutableStateOf(FormaPagamento.DINHEIRO) }
    var showCameraScanner by remember { mutableStateOf(false) }
    var showCustomerPicker by remember { mutableStateOf(false) }
    var showQuickAddCustomer by remember { mutableStateOf(false) }
    var showReceiptSignDialog by remember { mutableStateOf(false) }
    var saleSuccessNotice by remember { mutableStateOf<Long?>(null) }

    val cartTotal = cartItems.sumOf { it.subtotal }

    // Filter products for quick list
    val filteredProducts = remember(products, searchQuery) {
        if (searchQuery.isBlank()) {
            products.take(6)
        } else {
            products.filter {
                it.nome.contains(searchQuery, ignoreCase = true) ||
                        it.codigoBarras.contains(searchQuery, ignoreCase = true) ||
                        it.categoria.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // PDV Top Search Bar & Camera Scan Button
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Buscar produto ou código...", fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Limpar busca")
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("pdv_product_search_input")
                    )

                    Button(
                        onClick = { showCameraScanner = true },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .height(56.dp)
                            .testTag("pdv_camera_scanner_button")
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = "Ler Código", tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Câmera", color = Color.White, fontSize = 12.sp)
                    }
                }

                // Quick Product Chips when searching or empty
                if (filteredProducts.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(filteredProducts) { prod ->
                            FilterChip(
                                selected = false,
                                onClick = {
                                    viewModel.addToCart(prod, 1.0)
                                    searchQuery = ""
                                },
                                label = {
                                    Text(
                                        "${prod.nome} (${Formatters.formatCurrency(prod.precoVenda)})",
                                        fontSize = 12.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            )
                        }
                    }
                }
            }
        }

        // Cart and Checkout Area
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(6.dp))
                // Customer Selector Box
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { showCustomerPicker = true }
                        .testTag("pdv_customer_select_card"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedCustomer != null) ForestGreenLight else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (selectedCustomer != null) ForestGreen else Color.Gray),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = selectedCustomer?.nome ?: "Cliente Balcão / Não Identificado",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (selectedCustomer != null) ForestGreen else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (selectedCustomer != null)
                                        "CPF: ${Formatters.formatCpf(selectedCustomer!!.cpf)} • Limite: ${Formatters.formatCurrency(selectedCustomer!!.limiteCredito)}"
                                    else "Toque para vincular cliente (obrigatório para pagar no fim do mês)",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                            }
                        }

                        if (selectedCustomer != null) {
                            IconButton(onClick = { viewModel.selectCustomer(null) }) {
                                Icon(Icons.Default.Clear, contentDescription = "Remover cliente", tint = Color.DarkGray)
                            }
                        } else {
                            Text(
                                text = "Selecionar",
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // Cart Items Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Itens no Carrinho (${cartItems.sumOf { it.quantity.toInt() }})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (cartItems.isNotEmpty()) {
                        TextButton(onClick = { viewModel.clearCart() }, modifier = Modifier.testTag("pdv_clear_cart_button")) {
                            Text("Esvaziar", color = AlertRed, fontSize = 12.sp)
                        }
                    }
                }
            }

            if (cartItems.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.ShoppingCart,
                                contentDescription = null,
                                tint = Color.Gray,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Carrinho Vazio",
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Text(
                                text = "Escaneie o código de barras ou pesquise o produto acima.",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            } else {
                items(cartItems) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.product.nome,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "EAN: ${item.product.codigoBarras} • Unit: ${Formatters.formatCurrency(item.unitPrice)} / ${item.product.unidadeMedida}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray
                                )
                                Text(
                                    text = "Subtotal: ${Formatters.formatCurrency(item.subtotal)}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = ForestGreen
                                )
                            }

                            // Quantity Controls
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                IconButton(
                                    onClick = {
                                        viewModel.updateCartQuantity(item.product.codigoBarras, item.quantity - 1.0)
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(Color(0xFFE2E8F0), CircleShape)
                                ) {
                                    Icon(
                                        if (item.quantity <= 1.0) Icons.Default.Delete else Icons.Default.Remove,
                                        contentDescription = "Diminuir",
                                        tint = if (item.quantity <= 1.0) AlertRed else Color.DarkGray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                Text(
                                    text = "${item.quantity.toInt()} ${item.product.unidadeMedida}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp)
                                )

                                IconButton(
                                    onClick = {
                                        viewModel.updateCartQuantity(item.product.codigoBarras, item.quantity + 1.0)
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(ForestGreen, CircleShape)
                                ) {
                                    Icon(
                                        Icons.Default.Add,
                                        contentDescription = "Aumentar",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Payment Methods Section
            if (cartItems.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Forma de Pagamento",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        FormaPagamento.values().forEach { method ->
                            val isSelected = selectedPaymentMethod == method
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { selectedPaymentMethod = method }
                                    .border(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) (if (method == FormaPagamento.A_PRAZO_FIM_MES) WarmAmber else ForestGreen) else Color(0xFFE2E8F0),
                                        shape = RoundedCornerShape(8.dp)
                                    ),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) {
                                        if (method == FormaPagamento.A_PRAZO_FIM_MES) AmberLight else ForestGreenLight
                                    } else MaterialTheme.colorScheme.surface
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = when (method) {
                                                FormaPagamento.DINHEIRO -> Icons.Default.MonetizationOn
                                                FormaPagamento.PIX -> Icons.Default.QrCode
                                                FormaPagamento.CARTAO_DEBITO, FormaPagamento.CARTAO_CREDITO -> Icons.Default.CreditCard
                                                FormaPagamento.A_PRAZO_FIM_MES -> Icons.Default.Receipt
                                            },
                                            contentDescription = null,
                                            tint = if (method == FormaPagamento.A_PRAZO_FIM_MES) WarmAmber else ForestGreen
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = method.titulo,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.bodyMedium
                                            )
                                            if (method == FormaPagamento.A_PRAZO_FIM_MES) {
                                                Text(
                                                    text = "Emite recibo com assinatura digital do cliente • Juros de ${company.jurosMensalPercentual}% a.m. após fechamento",
                                                    fontSize = 10.sp,
                                                    color = Color(0xFF78350F)
                                                )
                                            }
                                        }
                                    }

                                    if (isSelected) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = null,
                                            tint = if (method == FormaPagamento.A_PRAZO_FIM_MES) WarmAmber else ForestGreen
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(100.dp)) }
        }

        // Checkout Footer Bottom Bar
        if (cartItems.isNotEmpty()) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 12.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "TOTAL A PAGAR",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.Gray,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = Formatters.formatCurrency(cartTotal),
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = ForestGreen
                            )
                        }

                        Button(
                            onClick = {
                                if (selectedPaymentMethod == FormaPagamento.A_PRAZO_FIM_MES) {
                                    if (selectedCustomer == null) {
                                        Toast.makeText(context, "Por favor selecione um cliente com CPF cadastrado para venda a prazo!", Toast.LENGTH_LONG).show()
                                        showCustomerPicker = true
                                    } else {
                                        // Open digital receipt for signature
                                        showReceiptSignDialog = true
                                    }
                                } else {
                                    // Immediate cash/card/pix sale
                                    viewModel.finalizeSale(
                                        formaPagamento = selectedPaymentMethod,
                                        onSuccess = { id ->
                                            saleSuccessNotice = id
                                            Toast.makeText(context, "Venda #$id finalizada com sucesso!", Toast.LENGTH_SHORT).show()
                                            onSaleFinished()
                                        }
                                    )
                                }
                            },
                            modifier = Modifier
                                .height(52.dp)
                                .testTag("pdv_finalize_sale_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedPaymentMethod == FormaPagamento.A_PRAZO_FIM_MES) WarmAmber else ForestGreen
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = if (selectedPaymentMethod == FormaPagamento.A_PRAZO_FIM_MES) Icons.Default.Receipt else Icons.Default.Check,
                                contentDescription = null,
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (selectedPaymentMethod == FormaPagamento.A_PRAZO_FIM_MES) "Emitir Recibo & Assinar" else "Finalizar Venda",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Camera Barcode Scanner
    if (showCameraScanner) {
        BarcodeCameraScannerDialog(
            onBarcodeDetected = { barcode ->
                showCameraScanner = false
                val product = products.find { it.codigoBarras == barcode }
                if (product != null) {
                    viewModel.addToCart(product, 1.0)
                    Toast.makeText(context, "${product.nome} adicionado ao carrinho!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Código de barras $barcode não encontrado no cadastro.", Toast.LENGTH_LONG).show()
                }
            },
            onDismiss = { showCameraScanner = false }
        )
    }

    // Customer Selection Dialog
    if (showCustomerPicker) {
        var custSearch by remember { mutableStateOf("") }
        val filteredCusts = customers.filter {
            it.nome.contains(custSearch, ignoreCase = true) || it.cpf.contains(custSearch)
        }

        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showCustomerPicker = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Selecionar Cliente")
                    TextButton(onClick = {
                        showCustomerPicker = false
                        showQuickAddCustomer = true
                    }) {
                        Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Novo", fontSize = 12.sp)
                    }
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = custSearch,
                        onValueChange = { custSearch = it },
                        placeholder = { Text("Buscar por CPF ou Nome...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    if (filteredCusts.isEmpty()) {
                        Text("Nenhum cliente cadastrado com esse CPF ou nome.", color = Color.Gray, fontSize = 12.sp)
                    } else {
                        LazyColumn(modifier = Modifier.height(250.dp)) {
                            items(filteredCusts) { cust ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            viewModel.selectCustomer(cust)
                                            showCustomerPicker = false
                                        }
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(cust.nome, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("CPF: ${Formatters.formatCpf(cust.cpf)}", fontSize = 11.sp, color = Color.Gray)
                                    }
                                    Text(
                                        "Limite: ${Formatters.formatCurrency(cust.limiteCredito)}",
                                        fontSize = 11.sp,
                                        color = ForestGreen,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                HorizontalDivider(thickness = 0.5.dp, color = Color.LightGray)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCustomerPicker = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Quick Add Customer Dialog
    if (showQuickAddCustomer) {
        var newCpf by remember { mutableStateOf("") }
        var newName by remember { mutableStateOf("") }
        var newPhone by remember { mutableStateOf("") }
        var newLimit by remember { mutableStateOf("1000.00") }

        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showQuickAddCustomer = false },
            title = { Text("Cadastro Rápido de Cliente") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newCpf,
                        onValueChange = { newCpf = it },
                        label = { Text("CPF (Chave Primária)*") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Nome Completo*") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newPhone,
                        onValueChange = { newPhone = it },
                        label = { Text("Telefone / WhatsApp") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newLimit,
                        onValueChange = { newLimit = it },
                        label = { Text("Limite de Crédito Fiado (R$)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val sanitizedCpf = newCpf.trim()
                        if (sanitizedCpf.isNotBlank() && newName.isNotBlank()) {
                            val cust = Customer(
                                cpf = sanitizedCpf,
                                nome = newName.trim(),
                                telefone = newPhone.trim(),
                                limiteCredito = newLimit.toDoubleOrNull() ?: 1000.0
                            )
                            viewModel.saveCustomer(cust) {
                                viewModel.selectCustomer(cust)
                                showQuickAddCustomer = false
                            }
                        } else {
                            Toast.makeText(context, "CPF e Nome são obrigatórios!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Salvar e Vincular")
                }
            },
            dismissButton = {
                TextButton(onClick = { showQuickAddCustomer = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Receipt with Interactive Touch Signature Dialog (for A Prazo / Fiado)
    if (showReceiptSignDialog && selectedCustomer != null) {
        val now = System.currentTimeMillis()
        val calculatedDueDate = InterestCalculator.calculateEndOfMonthDueDate(now, company.diaFechamentoMes)

        ReceiptSignAndConfirmDialog(
            company = company,
            customer = selectedCustomer!!,
            cartItems = cartItems,
            totalAmount = cartTotal,
            dueDate = calculatedDueDate,
            onConfirmSaleWithSignature = { signatureSvg ->
                viewModel.finalizeSale(
                    formaPagamento = FormaPagamento.A_PRAZO_FIM_MES,
                    signatureSvg = signatureSvg,
                    onSuccess = { saleId ->
                        showReceiptSignDialog = false
                        Toast.makeText(context, "Venda a Prazo #$saleId e Recibo Assinado salvos com sucesso!", Toast.LENGTH_LONG).show()
                        onSaleFinished()
                    }
                )
            },
            onDismiss = { showReceiptSignDialog = false }
        )
    }
}
