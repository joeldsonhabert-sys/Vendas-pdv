package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.FormaPagamento
import com.example.data.local.Sale
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.WarmAmber
import com.example.util.Formatters
import com.example.util.InterestCalculator

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentDialog(
    sale: Sale,
    jurosPercentualMensal: Double,
    onConfirmPayment: (amountPaid: Double, formaPagamento: FormaPagamento, observacao: String) -> Unit,
    onDismiss: () -> Unit
) {
    val calculation = remember(sale, jurosPercentualMensal) {
        InterestCalculator.calculateOverdueInterest(
            valorFinal = sale.valorFinal,
            valorPago = sale.valorPago,
            dataVencimento = sale.dataVencimento,
            jurosMensalPercentual = jurosPercentualMensal
        )
    }

    var amountInput by remember {
        mutableStateOf(String.format(java.util.Locale.US, "%.2f", calculation.valorTotalAtualizado))
    }
    var selectedPaymentMethod by remember { mutableStateOf(FormaPagamento.DINHEIRO) }
    var dropdownExpanded by remember { mutableStateOf(false) }
    var observacao by remember { mutableStateOf("") }

    val enteredAmount = amountInput.replace(",", ".").toDoubleOrNull() ?: 0.0

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .clip(RoundedCornerShape(16.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Receber Pagamento",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Fechar")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Sale Details & Calculations Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF8FAFC), RoundedCornerShape(10.dp))
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text(
                            text = "Venda #${sale.id} • ${sale.clienteNome ?: "Cliente"}",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "CPF: ${Formatters.formatCpf(sale.clienteCpf ?: "")}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.DarkGray
                        )
                        Text(
                            text = "Data da Compra: ${Formatters.formatDate(sale.dataHora)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.DarkGray
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        HorizontalDivider(thickness = 1.dp, color = Color.LightGray)
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Valor Original:", style = MaterialTheme.typography.bodySmall)
                            Text(Formatters.formatCurrency(sale.valorFinal), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                        }

                        if (sale.valorPago > 0.0) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Já Pago Anteriormente:", style = MaterialTheme.typography.bodySmall, color = Color(0xFF16A34A))
                                Text("- ${Formatters.formatCurrency(sale.valorPago)}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF16A34A))
                            }
                        }

                        if (calculation.estaEmAtraso) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "Juros por Atraso (${calculation.diasAtraso} dias):",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AlertRed,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "+ ${Formatters.formatCurrency(calculation.valorJuros)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AlertRed,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Total Atualizado com Juros:",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                Formatters.formatCurrency(calculation.valorTotalAtualizado),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (calculation.estaEmAtraso) AlertRed else ForestGreen
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Input for payment amount
                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("Valor a Pagar (R$)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("payment_amount_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Payment method dropdown
                ExposedDropdownMenuBox(
                    expanded = dropdownExpanded,
                    onExpandedChange = { dropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedPaymentMethod.titulo,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Forma de Pagamento") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )

                    ExposedDropdownMenu(
                        expanded = dropdownExpanded,
                        onDismissRequest = { dropdownExpanded = false }
                    ) {
                        listOf(
                            FormaPagamento.DINHEIRO,
                            FormaPagamento.PIX,
                            FormaPagamento.CARTAO_DEBITO,
                            FormaPagamento.CARTAO_CREDITO
                        ).forEach { method ->
                            DropdownMenuItem(
                                text = { Text(method.titulo) },
                                onClick = {
                                    selectedPaymentMethod = method
                                    dropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = observacao,
                    onValueChange = { observacao = it },
                    label = { Text("Observação / Comprovante (opcional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray)
                    ) {
                        Text("Cancelar", color = Color.DarkGray)
                    }

                    Button(
                        onClick = {
                            if (enteredAmount > 0) {
                                onConfirmPayment(enteredAmount, selectedPaymentMethod, observacao)
                            }
                        },
                        enabled = enteredAmount > 0,
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("confirm_receive_payment_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                    ) {
                        Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.padding(end = 4.dp))
                        Text("Confirmar")
                    }
                }
            }
        }
    }
}
