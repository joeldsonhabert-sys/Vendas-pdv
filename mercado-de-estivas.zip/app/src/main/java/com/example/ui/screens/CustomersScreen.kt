package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.Customer
import com.example.data.local.Sale
import com.example.data.local.SaleWithItems
import com.example.data.local.StatusPagamento
import com.example.ui.EstivasViewModel
import com.example.ui.components.PaymentDialog
import com.example.ui.components.ViewExistingReceiptDialog
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AlertRedLight
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.WarmAmber
import com.example.ui.theme.AmberLight
import com.example.util.Formatters
import com.example.util.InterestCalculator
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomersScreen(
    viewModel: EstivasViewModel
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val company by viewModel.companyProfile.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var customerToEdit by remember { mutableStateOf<Customer?>(null) }
    var isNewCustomerDialog by remember { mutableStateOf(false) }
    var viewingCustomerHistory by remember { mutableStateOf<Customer?>(null) }
    var selectedSaleForPayment by remember { mutableStateOf<Sale?>(null) }
    var selectedSaleWithItemsForReceipt by remember { mutableStateOf<SaleWithItems?>(null) }

    val filteredCustomers = remember(customers, searchQuery) {
        if (searchQuery.isBlank()) customers
        else customers.filter {
            it.nome.contains(searchQuery, ignoreCase = true) ||
                    it.cpf.contains(searchQuery) ||
                    it.telefone.contains(searchQuery)
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    customerToEdit = null
                    isNewCustomerDialog = true
                },
                containerColor = WarmAmber,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_customer_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Cadastrar Cliente")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search Bar
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Buscar por CPF ou Nome do cliente...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Limpar busca")
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("customers_search_input")
                    )
                }
            }

            // Customer List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Clientes Cadastrados (${filteredCustomers.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (filteredCustomers.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Nenhum cliente encontrado com esse CPF ou nome.", color = Color.Gray)
                        }
                    }
                } else {
                    items(filteredCustomers) { customer ->
                        val customerSales = sales.filter { it.clienteCpf == customer.cpf }
                        val pendingCreditSales = customerSales.filter { it.statusPagamento == StatusPagamento.PENDENTE || it.statusPagamento == StatusPagamento.ATRASADO }
                        val totalDebit = pendingCreditSales.sumOf { it.valorFinal - it.valorPago }
                        val hasOverdue = pendingCreditSales.any { it.statusPagamento == StatusPagamento.ATRASADO }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewingCustomerHistory = customer },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(if (totalDebit > 0) AmberLight else ForestGreenLight),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Person,
                                                contentDescription = null,
                                                tint = if (totalDebit > 0) WarmAmber else ForestGreen
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = customer.nome,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "CPF (PK): ${Formatters.formatCpf(customer.cpf)}",
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }

                                    if (totalDebit > 0) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(if (hasOverdue) AlertRedLight else AmberLight)
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = if (hasOverdue) "Em Atraso" else "Fiado Ativo",
                                                color = if (hasOverdue) AlertRed else Color(0xFFB45309),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                HorizontalDivider(thickness = 0.5.dp, color = Color.LightGray)
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Telefone: ${Formatters.formatPhone(customer.telefone).ifBlank { "-" }}", fontSize = 12.sp, color = Color.DarkGray)
                                        Text("Limite de Crédito: ${Formatters.formatCurrency(customer.limiteCredito)}", fontSize = 12.sp, color = Color.DarkGray)
                                        if (totalDebit > 0) {
                                            Text(
                                                text = "Saldo Devedor: ${Formatters.formatCurrency(totalDebit)}",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (hasOverdue) AlertRed else WarmAmber
                                            )
                                        }
                                    }

                                    Row {
                                        IconButton(
                                            onClick = {
                                                customerToEdit = customer
                                                isNewCustomerDialog = false
                                            }
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "Editar", tint = Color.DarkGray)
                                        }
                                        IconButton(
                                            onClick = { viewModel.deleteCustomer(customer.cpf) }
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Excluir", tint = AlertRed)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(80.dp)) }
            }
        }
    }

    // Add / Edit Customer Dialog
    if (isNewCustomerDialog || customerToEdit != null) {
        CustomerFormDialog(
            customer = customerToEdit,
            onSave = { customer ->
                viewModel.saveCustomer(customer) {
                    Toast.makeText(context, "Cliente salvo com sucesso!", Toast.LENGTH_SHORT).show()
                }
                customerToEdit = null
                isNewCustomerDialog = false
            },
            onDismiss = {
                customerToEdit = null
                isNewCustomerDialog = false
            }
        )
    }

    // Customer History Dialog
    viewingCustomerHistory?.let { customer ->
        val custSales = sales.filter { it.clienteCpf == customer.cpf }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { viewingCustomerHistory = null },
            title = {
                Column {
                    Text(customer.nome, fontWeight = FontWeight.Bold)
                    Text("CPF: ${Formatters.formatCpf(customer.cpf)}", fontSize = 12.sp, color = Color.Gray)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                ) {
                    Text(
                        text = "Histórico de Compras e Fiado",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    if (custSales.isEmpty()) {
                        Text("Nenhuma compra registrada para este cliente.", color = Color.Gray, fontSize = 12.sp)
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(custSales) { sale ->
                                val calculation = InterestCalculator.calculateOverdueInterest(
                                    valorFinal = sale.valorFinal,
                                    valorPago = sale.valorPago,
                                    dataVencimento = sale.dataVencimento,
                                    jurosMensalPercentual = company.jurosMensalPercentual
                                )

                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("Venda #${sale.id} • ${Formatters.formatDate(sale.dataHora)}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text(
                                                sale.statusPagamento.titulo,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = when (sale.statusPagamento) {
                                                    StatusPagamento.PAGO -> ForestGreen
                                                    StatusPagamento.ATRASADO -> AlertRed
                                                    StatusPagamento.PENDENTE -> WarmAmber
                                                    StatusPagamento.CANCELADO -> Color.Gray
                                                }
                                            )
                                        }

                                        Text("Valor: ${Formatters.formatCurrency(sale.valorFinal)} • Forma: ${sale.formaPagamento.titulo}", fontSize = 11.sp)

                                        if (calculation.estaEmAtraso) {
                                            Text(
                                                "Juros (${calculation.diasAtraso} dias): +${Formatters.formatCurrency(calculation.valorJuros)} | Total: ${Formatters.formatCurrency(calculation.valorTotalAtualizado)}",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = AlertRed
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))

                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            if (sale.reciboEmitido) {
                                                OutlinedButton(
                                                    onClick = {
                                                        scope.launch {
                                                            selectedSaleWithItemsForReceipt = viewModel.getSaleWithItems(sale.id)
                                                        }
                                                    },
                                                    modifier = Modifier.height(28.dp),
                                                    contentPadding = ButtonDefaults.TextButtonContentPadding
                                                ) {
                                                    Text("Ver Recibo", fontSize = 10.sp)
                                                }
                                            }

                                            if (sale.statusPagamento == StatusPagamento.PENDENTE || sale.statusPagamento == StatusPagamento.ATRASADO) {
                                                Button(
                                                    onClick = {
                                                        selectedSaleForPayment = sale
                                                        viewingCustomerHistory = null
                                                    },
                                                    modifier = Modifier.height(28.dp),
                                                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                                    contentPadding = ButtonDefaults.TextButtonContentPadding
                                                ) {
                                                    Text("Receber", fontSize = 10.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { viewingCustomerHistory = null }) {
                    Text("Fechar")
                }
            }
        )
    }

    // Payment Dialog
    selectedSaleForPayment?.let { sale ->
        PaymentDialog(
            sale = sale,
            jurosPercentualMensal = company.jurosMensalPercentual,
            onConfirmPayment = { amount, method, notes ->
                viewModel.registerPayment(
                    saleId = sale.id,
                    customerCpf = sale.clienteCpf ?: "",
                    amount = amount,
                    paymentMethod = method,
                    notes = notes
                )
                selectedSaleForPayment = null
            },
            onDismiss = { selectedSaleForPayment = null }
        )
    }

    // View Receipt Dialog
    selectedSaleWithItemsForReceipt?.let { details ->
        ViewExistingReceiptDialog(
            company = company,
            customerName = details.sale.clienteNome ?: "Cliente",
            customerCpf = details.sale.clienteCpf ?: "",
            saleId = details.sale.id,
            saleDate = details.sale.dataHora,
            dueDate = details.sale.dataVencimento,
            items = details.items,
            totalAmount = details.sale.valorFinal,
            signatureSvg = details.sale.assinaturaSvg,
            onDismiss = { selectedSaleWithItemsForReceipt = null }
        )
    }
}

@Composable
fun CustomerFormDialog(
    customer: Customer?,
    onSave: (Customer) -> Unit,
    onDismiss: () -> Unit
) {
    val isEditing = customer != null
    var cpf by remember { mutableStateOf(customer?.cpf ?: "") }
    var name by remember { mutableStateOf(customer?.nome ?: "") }
    var phone by remember { mutableStateOf(customer?.telefone ?: "") }
    var address by remember { mutableStateOf(customer?.endereco ?: "") }
    var creditLimit by remember { mutableStateOf(customer?.limiteCredito?.toString() ?: "1000.00") }
    var notes by remember { mutableStateOf(customer?.observacoes ?: "") }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (isEditing) "Editar Cliente" else "Cadastrar Novo Cliente")
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = cpf,
                    onValueChange = { if (!isEditing) cpf = it },
                    label = { Text("CPF (Chave Primária)*") },
                    readOnly = isEditing,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome Completo*") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Telefone / WhatsApp") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Endereço / Ponto de Referência") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = creditLimit,
                    onValueChange = { creditLimit = it },
                    label = { Text("Limite de Crédito Fiado (R$)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Observações (opcional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (cpf.isNotBlank() && name.isNotBlank()) {
                        val cust = Customer(
                            cpf = Formatters.sanitizeCpf(cpf),
                            nome = name.trim(),
                            telefone = phone.trim(),
                            endereco = address.trim(),
                            limiteCredito = creditLimit.replace(",", ".").toDoubleOrNull() ?: 1000.0,
                            observacoes = notes.trim()
                        )
                        onSave(cust)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = WarmAmber)
            ) {
                Text(if (isEditing) "Salvar Alterações" else "Cadastrar Cliente")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
