package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.Product
import com.example.data.local.Sale
import com.example.data.local.SaleWithItems
import com.example.ui.EstivasViewModel
import com.example.ui.components.PaymentDialog
import com.example.ui.components.ViewExistingReceiptDialog
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AlertRedLight
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.WarmAmber
import com.example.ui.theme.WarningOrange
import com.example.ui.theme.WarningOrangeLight
import com.example.util.Formatters
import com.example.util.InterestCalculator
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlertsScreen(
    viewModel: EstivasViewModel
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val company by viewModel.companyProfile.collectAsStateWithLifecycle()
    val lowStockProducts by viewModel.lowStockProducts.collectAsStateWithLifecycle()
    val overdueSales by viewModel.overdueSales.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    var replenishingProduct by remember { mutableStateOf<Product?>(null) }
    var selectedSaleForPayment by remember { mutableStateOf<Sale?>(null) }
    var selectedSaleWithItemsForReceipt by remember { mutableStateOf<SaleWithItems?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        PrimaryTabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Todos (${lowStockProducts.size + overdueSales.size})", fontSize = 12.sp)
                    }
                },
                modifier = Modifier.testTag("tab_all_alerts")
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = WarningOrange, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Estoque Baixo (${lowStockProducts.size})", fontSize = 12.sp)
                    }
                },
                modifier = Modifier.testTag("tab_stock_alerts")
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = AlertRed, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Em Atraso (${overdueSales.size})", fontSize = 12.sp)
                    }
                },
                modifier = Modifier.testTag("tab_overdue_alerts")
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Low Stock Section
            if (selectedTab == 0 || selectedTab == 1) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⚠️ Itens com Estoque Baixo (${lowStockProducts.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = WarningOrange
                        )
                    }
                }

                if (lowStockProducts.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Text(
                                text = "Nenhum produto com estoque crítico no momento.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.Gray,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                } else {
                    items(lowStockProducts) { product ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, WarningOrange.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = product.nome,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Código: ${product.codigoBarras} • Cat: ${product.categoria}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.Gray
                                        )
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(WarningOrangeLight)
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "${product.estoqueAtual} / min ${product.estoqueMinimo} ${product.unidadeMedida}",
                                            color = WarningOrange,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Venda: ${Formatters.formatCurrency(product.precoVenda)}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )

                                    Button(
                                        onClick = { replenishingProduct = product },
                                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Repor Estoque", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Overdue Accounts Section
            if (selectedTab == 0 || selectedTab == 2) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "🚨 Contas em Atraso pós-Fechamento de Mês (${overdueSales.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = AlertRed
                    )
                    Text(
                        text = "Taxa configurada: ${company.jurosMensalPercentual}% ao mês de juros de mora",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.DarkGray
                    )
                }

                if (overdueSales.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Text(
                                text = "Nenhuma conta em atraso! Todos os pagamentos a prazo estão em dia.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.Gray,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                } else {
                    items(overdueSales) { sale ->
                        val calculation = InterestCalculator.calculateOverdueInterest(
                            valorFinal = sale.valorFinal,
                            valorPago = sale.valorPago,
                            dataVencimento = sale.dataVencimento,
                            jurosMensalPercentual = company.jurosMensalPercentual
                        )

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, AlertRed.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = sale.clienteNome ?: "Cliente CPF: ${sale.clienteCpf}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "CPF: ${Formatters.formatCpf(sale.clienteCpf ?: "")}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.DarkGray
                                        )
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(AlertRedLight)
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "${calculation.diasAtraso} dias de atraso",
                                            color = AlertRed,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Compra: ${Formatters.formatDate(sale.dataHora)}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                    Text("Vencimento: ${Formatters.formatDate(sale.dataVencimento)}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                HorizontalDivider(thickness = 0.5.dp, color = Color.LightGray)
                                Spacer(modifier = Modifier.height(6.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("Valor Original: ${Formatters.formatCurrency(sale.valorFinal)}", fontSize = 12.sp)
                                        Text("Juros de Mora: +${Formatters.formatCurrency(calculation.valorJuros)}", fontSize = 12.sp, color = AlertRed, fontWeight = FontWeight.Bold)
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("Total Atualizado:", fontSize = 11.sp, color = Color.Gray)
                                        Text(
                                            text = Formatters.formatCurrency(calculation.valorTotalAtualizado),
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = AlertRed
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            scope.launch {
                                                val details = viewModel.getSaleWithItems(sale.id)
                                                selectedSaleWithItemsForReceipt = details
                                            }
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Ver Recibo", fontSize = 11.sp)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            val shareText = "Olá ${sale.clienteNome}! Notificamos que a sua conta a prazo no ${company.nomeFantasia} (Venda #${sale.id}) venceu em ${Formatters.formatDate(sale.dataVencimento)}. Saldo atualizado com juros: ${Formatters.formatCurrency(calculation.valorTotalAtualizado)}. Favor comparecer para quitação."
                                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(Intent.EXTRA_TEXT, shareText)
                                            }
                                            context.startActivity(Intent.createChooser(sendIntent, "Notificar Cliente"))
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Notificar", fontSize = 11.sp)
                                    }

                                    Button(
                                        onClick = { selectedSaleForPayment = sale },
                                        colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                                        modifier = Modifier.weight(1.2f)
                                    ) {
                                        Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Receber", fontSize = 11.sp, color = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(30.dp)) }
        }
    }

    // Replenishment Dialog
    replenishingProduct?.let { product ->
        var addQty by remember { mutableStateOf("20") }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { replenishingProduct = null },
            title = { Text("Repor Estoque: ${product.nome}") },
            text = {
                Column {
                    Text("Estoque atual: ${product.estoqueAtual} ${product.unidadeMedida}")
                    Text("Estoque mínimo: ${product.estoqueMinimo} ${product.unidadeMedida}")
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = addQty,
                        onValueChange = { addQty = it },
                        label = { Text("Quantidade a adicionar (${product.unidadeMedida})") },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val qty = addQty.toDoubleOrNull() ?: 0.0
                        if (qty > 0) {
                            viewModel.replenishStock(product.codigoBarras, qty, "Reposição de Alerta")
                        }
                        replenishingProduct = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Confirmar Entrada")
                }
            },
            dismissButton = {
                TextButton(onClick = { replenishingProduct = null }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Payment Dialog
    selectedSaleForPayment?.let { sale ->
        PaymentDialog(
            sale = sale,
            jurosPercentualMensal = company.jurosMensalPercentual,
            onConfirmPayment = { amount, method, notes ->
                viewModel.registerPayment(
                    saleId = sale.id,
                    customerCpf = sale.clienteCpf ?: "",
                    amount = amount,
                    paymentMethod = method,
                    notes = notes
                )
                selectedSaleForPayment = null
            },
            onDismiss = { selectedSaleForPayment = null }
        )
    }

    // View Existing Receipt Dialog
    selectedSaleWithItemsForReceipt?.let { details ->
        ViewExistingReceiptDialog(
            company = company,
            customerName = details.sale.clienteNome ?: "Cliente",
            customerCpf = details.sale.clienteCpf ?: "",
            saleId = details.sale.id,
            saleDate = details.sale.dataHora,
            dueDate = details.sale.dataVencimento,
            items = details.items,
            totalAmount = details.sale.valorFinal,
            signatureSvg = details.sale.assinaturaSvg,
            onDismiss = { selectedSaleWithItemsForReceipt = null }
        )
    }
}
