package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.CompanyProfile
import com.example.data.local.Customer
import com.example.data.local.FormaPagamento
import com.example.data.local.Product
import com.example.data.local.Sale
import com.example.data.local.SaleItem
import com.example.data.local.SaleWithItems
import com.example.data.local.StockMovement
import com.example.data.repository.CartItem
import com.example.data.repository.EstivasRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class EstivasViewModel(private val repository: EstivasRepository) : ViewModel() {

    init {
        // Sync overdue statuses upon startup
        viewModelScope.launch {
            repository.syncAllOverdueStatus()
        }
    }

    val companyProfile: StateFlow<CompanyProfile> = repository.companyProfileFlow
        .combine(MutableStateFlow(CompanyProfile())) { profile, default ->
            profile ?: default
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CompanyProfile())

    val products: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockProducts: StateFlow<List<Product>> = repository.lowStockProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockCount: StateFlow<Int> = repository.lowStockCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val customers: StateFlow<List<Customer>> = repository.allCustomers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sales: StateFlow<List<Sale>> = repository.allSales
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val receivableSales: StateFlow<List<Sale>> = repository.receivableSales
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val overdueSales: StateFlow<List<Sale>> = repository.overdueSales
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val overdueCount: StateFlow<Int> = repository.overdueCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val recentMovements: StateFlow<List<StockMovement>> = repository.recentStockMovements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- PDV / Cart State ---
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    private val _selectedCustomer = MutableStateFlow<Customer?>(null)
    val selectedCustomer: StateFlow<Customer?> = _selectedCustomer.asStateFlow()

    private val _lastCompletedSaleId = MutableStateFlow<Long?>(null)
    val lastCompletedSaleId: StateFlow<Long?> = _lastCompletedSaleId.asStateFlow()

    fun addToCart(product: Product, quantity: Double = 1.0) {
        val currentList = _cartItems.value.toMutableList()
        val index = currentList.indexOfFirst { it.product.codigoBarras == product.codigoBarras }
        if (index >= 0) {
            val existing = currentList[index]
            currentList[index] = existing.copy(quantity = existing.quantity + quantity)
        } else {
            currentList.add(CartItem(product = product, quantity = quantity))
        }
        _cartItems.value = currentList
    }

    fun updateCartQuantity(barcode: String, newQuantity: Double) {
        if (newQuantity <= 0) {
            removeFromCart(barcode)
            return
        }
        val currentList = _cartItems.value.toMutableList()
        val index = currentList.indexOfFirst { it.product.codigoBarras == barcode }
        if (index >= 0) {
            currentList[index] = currentList[index].copy(quantity = newQuantity)
            _cartItems.value = currentList
        }
    }

    fun removeFromCart(barcode: String) {
        _cartItems.value = _cartItems.value.filterNot { it.product.codigoBarras == barcode }
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _selectedCustomer.value = null
    }

    fun selectCustomer(customer: Customer?) {
        _selectedCustomer.value = customer
    }

    fun finalizeSale(
        formaPagamento: FormaPagamento,
        desconto: Double = 0.0,
        signatureSvg: String? = null,
        onSuccess: (Long) -> Unit
    ) {
        val items = _cartItems.value
        if (items.isEmpty()) return

        val customer = _selectedCustomer.value

        viewModelScope.launch {
            val saleId = repository.registerSale(
                items = items,
                customer = customer,
                formaPagamento = formaPagamento,
                desconto = desconto,
                signatureSvg = signatureSvg
            )
            _lastCompletedSaleId.value = saleId
            clearCart()
            onSuccess(saleId)
        }
    }

    // --- Product Actions ---
    fun saveProduct(product: Product, isNew: Boolean = false, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveProduct(product, isNew)
            onComplete()
        }
    }

    fun deleteProduct(barcode: String) {
        viewModelScope.launch {
            repository.deleteProduct(barcode)
        }
    }

    fun replenishStock(barcode: String, quantity: Double, motivo: String = "Reposição de Estoque") {
        viewModelScope.launch {
            repository.addStockToProduct(barcode, quantity, motivo)
        }
    }

    suspend fun getProductByBarcode(barcode: String): Product? {
        return repository.getProductByBarcode(barcode)
    }

    // --- Customer Actions ---
    fun saveCustomer(customer: Customer, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveCustomer(customer)
            onComplete()
        }
    }

    fun deleteCustomer(cpf: String) {
        viewModelScope.launch {
            repository.deleteCustomer(cpf)
        }
    }

    // --- Payment Registration ---
    fun registerPayment(
        saleId: Long,
        customerCpf: String,
        amount: Double,
        paymentMethod: FormaPagamento,
        notes: String,
        onComplete: (Boolean) -> Unit = {}
    ) {
        viewModelScope.launch {
            val success = repository.registerPayment(
                saleId = saleId,
                customerCpf = customerCpf,
                amountPaid = amount,
                formaPagamento = paymentMethod,
                observacao = notes
            )
            repository.syncAllOverdueStatus()
            onComplete(success)
        }
    }

    suspend fun getSaleWithItems(saleId: Long): SaleWithItems? {
        return repository.getSaleWithItems(saleId)
    }

    // --- Company Actions ---
    fun updateCompanyProfile(profile: CompanyProfile, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveCompanyProfile(profile)
            repository.syncAllOverdueStatus()
            onComplete()
        }
    }
}

class EstivasViewModelFactory(private val repository: EstivasRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(EstivasViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return EstivasViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
