package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.CompanyProfile
import com.example.ui.EstivasViewModel
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.WarmAmber
import com.example.ui.theme.AmberLight
import com.example.util.Formatters

@Composable
fun CompanySettingsScreen(
    viewModel: EstivasViewModel
) {
    val context = LocalContext.current
    val company by viewModel.companyProfile.collectAsStateWithLifecycle()

    var razaoSocial by remember(company) { mutableStateOf(company.razaoSocial) }
    var nomeFantasia by remember(company) { mutableStateOf(company.nomeFantasia) }
    var cnpj by remember(company) { mutableStateOf(company.cnpj) }
    var telefone by remember(company) { mutableStateOf(company.telefone) }
    var endereco by remember(company) { mutableStateOf(company.endereco) }
    var cidade by remember(company) { mutableStateOf(company.cidade) }
    var jurosMensal by remember(company) { mutableStateOf(company.jurosMensalPercentual.toString()) }
    var diaFechamento by remember(company) { mutableStateOf(company.diaFechamentoMes.toString()) }
    var mensagemRecibo by remember(company) { mutableStateOf(company.mensagemRecibo) }

    // Interactive Interest Simulation state
    var simValor by remember { mutableStateOf("100.00") }
    var simDiasAtraso by remember { mutableStateOf("15") }

    val simRate = jurosMensal.replace(",", ".").toDoubleOrNull() ?: 3.0
    val simVal = simValor.replace(",", ".").toDoubleOrNull() ?: 100.0
    val simDias = simDiasAtraso.toLongOrNull() ?: 15L
    val simJurosCalculado = simVal * ((simRate / 100.0) / 30.0) * simDias
    val simTotal = simVal + simJurosCalculado

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Business,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Cadastro da Empresa & Parâmetros Financeiros",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Configure dados da estiva, percentual de juros e fechamento do ciclo",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }
        }

        // Company Details Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Dados do Estabelecimento",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = nomeFantasia,
                    onValueChange = { nomeFantasia = it },
                    label = { Text("Nome Fantasia*") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("company_trading_name_input")
                )

                OutlinedTextField(
                    value = razaoSocial,
                    onValueChange = { razaoSocial = it },
                    label = { Text("Razão Social") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = cnpj,
                        onValueChange = { cnpj = it },
                        label = { Text("CNPJ*") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = telefone,
                        onValueChange = { telefone = it },
                        label = { Text("Telefone / WhatsApp") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = endereco,
                    onValueChange = { endereco = it },
                    label = { Text("Endereço Completo") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = cidade,
                    onValueChange = { cidade = it },
                    label = { Text("Cidade / UF") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Financial & Interest Settings Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = AmberLight)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Percent,
                        contentDescription = null,
                        tint = WarmAmber,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Parâmetros de Juros e Fechamento de Ciclo",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF78350F)
                    )
                }

                Text(
                    text = "O ciclo de compras a prazo fecha todo final de mês. A partir do fechamento, as contas pendentes começam a acumular juros de mora com base na taxa percentual definida abaixo pelo responsável financeiro.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF92400E)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = jurosMensal,
                        onValueChange = { jurosMensal = it },
                        label = { Text("Taxa de Juros (% ao mês)*") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("company_interest_rate_input")
                    )

                    OutlinedTextField(
                        value = diaFechamento,
                        onValueChange = { diaFechamento = it },
                        label = { Text("Dia Fechamento (Ex: 30)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = mensagemRecibo,
                    onValueChange = { mensagemRecibo = it },
                    label = { Text("Texto da Cláusula do Recibo de Venda a Prazo") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Live Interest Simulator Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Calculate,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Simulador Financeiro de Juros por Atraso",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = simValor,
                        onValueChange = { simValor = it },
                        label = { Text("Valor da Compra (R$)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = simDiasAtraso,
                        onValueChange = { simDiasAtraso = it },
                        label = { Text("Dias em Atraso") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFE2E8F0))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Juros Calculados (${simRate}% a.m.):", fontSize = 12.sp, color = AlertRed, fontWeight = FontWeight.Bold)
                            Text(Formatters.formatCurrency(simJurosCalculado), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AlertRed)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Total Atualizado a Cobrar:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(Formatters.formatCurrency(simTotal), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = ForestGreen)
                        }
                    }
                }
            }
        }

        // Save Button
        Button(
            onClick = {
                val newRate = jurosMensal.replace(",", ".").toDoubleOrNull() ?: 3.0
                val newDay = diaFechamento.toIntOrNull() ?: 30
                val updatedProfile = company.copy(
                    razaoSocial = razaoSocial.trim(),
                    nomeFantasia = nomeFantasia.trim(),
                    cnpj = Formatters.sanitizeCpf(cnpj),
                    telefone = telefone.trim(),
                    endereco = endereco.trim(),
                    cidade = cidade.trim(),
                    jurosMensalPercentual = newRate,
                    diaFechamentoMes = newDay,
                    mensagemRecibo = mensagemRecibo.trim()
                )
                viewModel.updateCompanyProfile(updatedProfile) {
                    Toast.makeText(context, "Dados da empresa e parâmetros de juros salvos!", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("save_company_profile_button"),
            colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Save, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Salvar Alterações e Atualizar Juros", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}
