package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.FormaPagamento
import com.example.data.local.StatusPagamento
import com.example.ui.EstivasViewModel
import com.example.ui.components.BarChartItem
import com.example.ui.components.DonutSlice
import com.example.ui.components.SimpleBarChart
import com.example.ui.components.SimpleDonutChart
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.WarmAmber
import com.example.ui.theme.AmberLight
import com.example.util.Formatters
import com.example.util.InterestCalculator
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun ReportsScreen(
    viewModel: EstivasViewModel
) {
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()
    val company by viewModel.companyProfile.collectAsStateWithLifecycle()
    val overdueSales by viewModel.overdueSales.collectAsStateWithLifecycle()

    val totalRevenue = sales.filter { it.statusPagamento != StatusPagamento.CANCELADO }.sumOf { it.valorFinal }
    val totalPaid = sales.sumOf { it.valorPago }
    val totalReceivable = sales.filter { it.statusPagamento == StatusPagamento.PENDENTE || it.statusPagamento == StatusPagamento.ATRASADO }.sumOf { it.valorFinal - it.valorPago }

    val totalAccruedInterest = overdueSales.sumOf { sale ->
        val calc = InterestCalculator.calculateOverdueInterest(
            valorFinal = sale.valorFinal,
            valorPago = sale.valorPago,
            dataVencimento = sale.dataVencimento,
            jurosMensalPercentual = company.jurosMensalPercentual
        )
        calc.valorJuros
    }

    // Payment methods breakdown
    val paymentSlices = remember(sales) {
        val groups = sales.groupBy { it.formaPagamento }
        listOf(
            DonutSlice("Dinheiro", groups[FormaPagamento.DINHEIRO]?.sumOf { it.valorFinal } ?: 0.0, ForestGreen),
            DonutSlice("PIX", groups[FormaPagamento.PIX]?.sumOf { it.valorFinal } ?: 0.0, Color(0xFF0284C7)),
            DonutSlice("Cartão", ((groups[FormaPagamento.CARTAO_DEBITO]?.sumOf { it.valorFinal } ?: 0.0) + (groups[FormaPagamento.CARTAO_CREDITO]?.sumOf { it.valorFinal } ?: 0.0)), Color(0xFF7C3AED)),
            DonutSlice("Fiado (Fim do Mês)", groups[FormaPagamento.A_PRAZO_FIM_MES]?.sumOf { it.valorFinal } ?: 0.0, WarmAmber)
        )
    }

    // Daily Sales Bar Chart (Last 7 days)
    val dailySalesItems = remember(sales) {
        val dateFormat = SimpleDateFormat("dd/MM", Locale("pt", "BR"))
        val dayNames = SimpleDateFormat("EEE", Locale("pt", "BR"))
        val calendar = Calendar.getInstance()

        (6 downTo 0).map { daysAgo ->
            val targetCal = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, -daysAgo)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val startOfDay = targetCal.timeInMillis
            val endOfDay = startOfDay + 24 * 60 * 60 * 1000 - 1

            val dayTotal = sales.filter {
                it.dataHora in startOfDay..endOfDay && it.statusPagamento != StatusPagamento.CANCELADO
            }.sumOf { it.valorFinal }

            val label = "${dayNames.format(targetCal.time).replace(".", "").uppercase()} (${dateFormat.format(targetCal.time)})"
            BarChartItem(
                label = label,
                value = dayTotal,
                formattedValue = Formatters.formatCurrency(dayTotal)
            )
        }
    }

    // Receivable vs Received Donut
    val receivableSlices = remember(totalPaid, totalReceivable, totalAccruedInterest) {
        listOf(
            DonutSlice("Recebido / Quitado", totalPaid, ForestGreen),
            DonutSlice("Fiado a Vencer", maxOf(0.0, totalReceivable - overdueSales.sumOf { it.valorFinal - it.valorPago }), WarmAmber),
            DonutSlice("Fiado em Atraso", overdueSales.sumOf { it.valorFinal - it.valorPago }, AlertRed),
            DonutSlice("Juros por Atraso", totalAccruedInterest, Color(0xFF9333EA))
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Gráficos e Relatórios Financeiros",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Visão panorâmica de vendas, formas de pagamento e contas a receber",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }

        // Summary Metric Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "Total Vendas",
                    value = Formatters.formatCurrency(totalRevenue),
                    subtitle = "${sales.size} transações",
                    icon = Icons.Default.TrendingUp,
                    cardColor = ForestGreenLight,
                    iconTint = ForestGreen,
                    modifier = Modifier.weight(1f)
                )

                MetricCard(
                    title = "Juros de Mora",
                    value = Formatters.formatCurrency(totalAccruedInterest),
                    subtitle = "${company.jurosMensalPercentual}% ao mês",
                    icon = Icons.Default.AccountBalanceWallet,
                    cardColor = AmberLight,
                    iconTint = WarmAmber,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Daily Revenue Bar Chart
        item {
            SimpleBarChart(
                title = "📊 Faturamento Diário (Últimos 7 Dias)",
                items = dailySalesItems,
                barColor = ForestGreen
            )
        }

        // Payment Methods Donut Chart
        item {
            SimpleDonutChart(
                title = "💳 Vendas por Forma de Pagamento",
                slices = paymentSlices
            )
        }

        // Receivable & Interest Chart
        item {
            SimpleDonutChart(
                title = "⚖️ Balanço: Recebido vs Fiado & Juros",
                slices = receivableSlices
            )
        }

        item { Spacer(modifier = Modifier.height(30.dp)) }
    }
}
