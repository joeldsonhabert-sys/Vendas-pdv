package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.Product
import com.example.ui.EstivasViewModel
import com.example.ui.components.BarcodeCameraScannerDialog
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AlertRedLight
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.WarmAmber
import com.example.ui.theme.WarningOrange
import com.example.ui.theme.WarningOrangeLight
import com.example.util.Formatters

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductsScreen(
    viewModel: EstivasViewModel
) {
    val context = LocalContext.current
    val products by viewModel.products.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var showCameraScanner by remember { mutableStateOf(false) }
    var productToEdit by remember { mutableStateOf<Product?>(null) }
    var isNewProductDialog by remember { mutableStateOf(false) }
    var replenishingProduct by remember { mutableStateOf<Product?>(null) }
    var scannedBarcodePreFill by remember { mutableStateOf<String?>(null) }

    val categories = remember(products) {
        listOf("Todos") + products.map { it.categoria }.distinct().sorted()
    }

    val filteredProducts = remember(products, searchQuery, selectedCategory) {
        products.filter { prod ->
            val matchSearch = searchQuery.isBlank() ||
                    prod.nome.contains(searchQuery, ignoreCase = true) ||
                    prod.codigoBarras.contains(searchQuery, ignoreCase = true)
            val matchCategory = selectedCategory == null || selectedCategory == "Todos" || prod.categoria == selectedCategory
            matchSearch && matchCategory
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    scannedBarcodePreFill = null
                    productToEdit = null
                    isNewProductDialog = true
                },
                containerColor = ForestGreen,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_product_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Cadastrar Produto")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search & Scan Bar
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Buscar por nome ou código de barras...", fontSize = 13.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            trailingIcon = {
                                if (searchQuery.isNotBlank()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Limpar")
                                    }
                                }
                            },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("products_search_input")
                        )

                        Button(
                            onClick = { showCameraScanner = true },
                            colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(56.dp)
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Categories Horizontal Row
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(categories) { cat ->
                            val isSelected = (selectedCategory == null && cat == "Todos") || selectedCategory == cat
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    selectedCategory = if (cat == "Todos") null else cat
                                },
                                label = { Text(cat, fontSize = 12.sp) }
                            )
                        }
                    }
                }
            }

            // Products List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Produtos Cadastrados (${filteredProducts.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (filteredProducts.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Nenhum produto encontrado.", color = Color.Gray)
                        }
                    }
                } else {
                    items(filteredProducts) { product ->
                        val isLowStock = product.estoqueAtual <= product.estoqueMinimo

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = product.nome,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Código de Barras (PK): ${product.codigoBarras}",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "Categoria: ${product.categoria} • Unidade: ${product.unidadeMedida}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.Gray
                                        )
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (isLowStock) WarningOrangeLight else ForestGreenLight)
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "${product.estoqueAtual} ${product.unidadeMedida}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = if (isLowStock) WarningOrange else ForestGreen
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                HorizontalDivider(thickness = 0.5.dp, color = Color.LightGray)
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                        Column {
                                            Text("Preço Custo", fontSize = 11.sp, color = Color.Gray)
                                            Text(Formatters.formatCurrency(product.precoCusto), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                        }
                                        Column {
                                            Text("Preço Venda", fontSize = 11.sp, color = Color.Gray)
                                            Text(
                                                Formatters.formatCurrency(product.precoVenda),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = ForestGreen
                                            )
                                        }
                                        Column {
                                            Text("Estoque Mínimo", fontSize = 11.sp, color = Color.Gray)
                                            Text("${product.estoqueMinimo} ${product.unidadeMedida}", fontSize = 12.sp)
                                        }
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        IconButton(
                                            onClick = { replenishingProduct = product },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(Icons.Default.Inventory, contentDescription = "Repor Estoque", tint = ForestGreen)
                                        }
                                        IconButton(
                                            onClick = {
                                                productToEdit = product
                                                isNewProductDialog = false
                                            },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "Editar", tint = Color.DarkGray)
                                        }
                                        IconButton(
                                            onClick = { viewModel.deleteProduct(product.codigoBarras) },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Excluir", tint = AlertRed)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(80.dp)) }
            }
        }
    }

    // Camera Barcode Scanner for quick lookup or new registration
    if (showCameraScanner) {
        BarcodeCameraScannerDialog(
            onBarcodeDetected = { barcode ->
                showCameraScanner = false
                val existing = products.find { it.codigoBarras == barcode }
                if (existing != null) {
                    productToEdit = existing
                    isNewProductDialog = false
                } else {
                    scannedBarcodePreFill = barcode
                    productToEdit = null
                    isNewProductDialog = true
                }
            },
            onDismiss = { showCameraScanner = false }
        )
    }

    // Add / Edit Product Dialog
    if (isNewProductDialog || productToEdit != null) {
        ProductFormDialog(
            product = productToEdit,
            preFilledBarcode = scannedBarcodePreFill,
            onSave = { product, isNew ->
                viewModel.saveProduct(product, isNew) {
                    Toast.makeText(context, "Produto salvo com sucesso!", Toast.LENGTH_SHORT).show()
                }
                productToEdit = null
                isNewProductDialog = false
                scannedBarcodePreFill = null
            },
            onDismiss = {
                productToEdit = null
                isNewProductDialog = false
                scannedBarcodePreFill = null
            }
        )
    }

    // Quick Replenish Dialog
    replenishingProduct?.let { product ->
        var addQty by remember { mutableStateOf("10") }
        var motivo by remember { mutableStateOf("Reposição Fornecedor") }

        androidx.compose.material3.AlertDialog(
            onDismissRequest = { replenishingProduct = null },
            title = { Text("Repor Estoque: ${product.nome}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Estoque atual: ${product.estoqueAtual} ${product.unidadeMedida}")
                    OutlinedTextField(
                        value = addQty,
                        onValueChange = { addQty = it },
                        label = { Text("Quantidade a Adicionar (${product.unidadeMedida})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = motivo,
                        onValueChange = { motivo = it },
                        label = { Text("Motivo / Observação") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val qty = addQty.toDoubleOrNull() ?: 0.0
                        if (qty > 0) {
                            viewModel.replenishStock(product.codigoBarras, qty, motivo)
                        }
                        replenishingProduct = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Confirmar Entrada")
                }
            },
            dismissButton = {
                TextButton(onClick = { replenishingProduct = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductFormDialog(
    product: Product?,
    preFilledBarcode: String?,
    onSave: (Product, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val isEditing = product != null
    var barcode by remember { mutableStateOf(product?.codigoBarras ?: preFilledBarcode ?: "") }
    var name by remember { mutableStateOf(product?.nome ?: "") }
    var category by remember { mutableStateOf(product?.categoria ?: "Grãos & Cereais") }
    var unit by remember { mutableStateOf(product?.unidadeMedida ?: "kg") }
    var costPrice by remember { mutableStateOf(product?.precoCusto?.toString() ?: "") }
    var salePrice by remember { mutableStateOf(product?.precoVenda?.toString() ?: "") }
    var currentStock by remember { mutableStateOf(product?.estoqueAtual?.toString() ?: "0.0") }
    var minStock by remember { mutableStateOf(product?.estoqueMinimo?.toString() ?: "5.0") }

    val categoryOptions = listOf(
        "Grãos & Cereais",
        "Farináceos",
        "Óleos & Gorduras",
        "Açúcares & Doces",
        "Conservas & Enlatados",
        "Matinais & Bebidas",
        "Condimentos & Molhos",
        "Limpeza & Higiene"
    )

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (isEditing) "Editar Produto" else "Novo Produto de Estivas")
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = barcode,
                    onValueChange = { if (!isEditing) barcode = it },
                    label = { Text("Código de Barras (Chave Primária)*") },
                    readOnly = isEditing,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome do Produto (Ex: Arroz Tipo 1 5kg)*") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Categoria") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Unidade (kg/un/pct)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = costPrice,
                        onValueChange = { costPrice = it },
                        label = { Text("Preço Custo (R$)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = salePrice,
                        onValueChange = { salePrice = it },
                        label = { Text("Preço Venda (R$)*") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = minStock,
                        onValueChange = { minStock = it },
                        label = { Text("Estoque Mínimo") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = currentStock,
                    onValueChange = { currentStock = it },
                    label = { Text("Estoque Atual") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (barcode.isNotBlank() && name.isNotBlank() && salePrice.isNotBlank()) {
                        val prod = Product(
                            codigoBarras = barcode.trim(),
                            nome = name.trim(),
                            categoria = category.trim(),
                            unidadeMedida = unit.trim(),
                            precoCusto = costPrice.replace(",", ".").toDoubleOrNull() ?: 0.0,
                            precoVenda = salePrice.replace(",", ".").toDoubleOrNull() ?: 0.0,
                            estoqueAtual = currentStock.replace(",", ".").toDoubleOrNull() ?: 0.0,
                            estoqueMinimo = minStock.replace(",", ".").toDoubleOrNull() ?: 5.0
                        )
                        onSave(prod, !isEditing)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
            ) {
                Text(if (isEditing) "Salvar Alterações" else "Cadastrar Produto")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
