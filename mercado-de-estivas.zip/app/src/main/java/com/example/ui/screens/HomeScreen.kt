package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.CompanyProfile
import com.example.data.local.Customer
import com.example.data.local.FormaPagamento
import com.example.data.local.Product
import com.example.data.local.Sale
import com.example.data.local.StatusPagamento
import com.example.ui.EstivasViewModel
import com.example.ui.components.BarcodeCameraScannerDialog
import com.example.ui.components.PaymentDialog
import com.example.ui.components.ViewExistingReceiptDialog
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AlertRedLight
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.WarmAmber
import com.example.ui.theme.AmberLight
import com.example.ui.theme.WarningOrange
import com.example.ui.theme.WarningOrangeLight
import com.example.util.Formatters
import com.example.util.InterestCalculator
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: EstivasViewModel,
    onNavigateToPdv: () -> Unit,
    onNavigateToProducts: () -> Unit,
    onNavigateToCustomers: () -> Unit,
    onNavigateToAlerts: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToCompany: () -> Unit
) {
    val company by viewModel.companyProfile.collectAsStateWithLifecycle()
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val lowStockProducts by viewModel.lowStockProducts.collectAsStateWithLifecycle()
    val overdueSales by viewModel.overdueSales.collectAsStateWithLifecycle()
    val receivableSales by viewModel.receivableSales.collectAsStateWithLifecycle()

    var showCameraScanner by remember { mutableStateOf(false) }
    var scannedProductAlert by remember { mutableStateOf<Product?>(null) }
    var selectedSaleForPayment by remember { mutableStateOf<Sale?>(null) }
    var replenishingProduct by remember { mutableStateOf<Product?>(null) }

    // Calculate metrics
    val startOfToday = remember {
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    val todaySales = sales.filter { it.dataHora >= startOfToday && it.statusPagamento != StatusPagamento.CANCELADO }
    val todayRevenue = todaySales.sumOf { if (it.formaPagamento == FormaPagamento.A_PRAZO_FIM_MES) it.valorPago else it.valorFinal }
    val totalReceivable = receivableSales.sumOf { it.valorFinal - it.valorPago }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))

            // Company Greeting Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = company.nomeFantasia.ifBlank { "Mercado de Estivas" },
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "CNPJ: ${Formatters.formatCnpj(company.cnpj)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }

                        IconButton(
                            onClick = onNavigateToCompany,
                            modifier = Modifier
                                .background(Color.White.copy(alpha = 0.2f), CircleShape)
                                .testTag("company_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Business,
                                contentDescription = "Dados da Empresa",
                                tint = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onNavigateToPdv,
                            modifier = Modifier
                                .weight(1.3f)
                                .testTag("home_new_sale_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = WarmAmber)
                        ) {
                            Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Nova Venda (PDV)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                        }

                        Button(
                            onClick = { showCameraScanner = true },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("home_scan_barcode_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.25f))
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Ler Código", color = Color.White, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Summary Metric Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = "Vendas Hoje",
                    value = Formatters.formatCurrency(todayRevenue),
                    subtitle = "${todaySales.size} operações",
                    icon = Icons.Default.PointOfSale,
                    cardColor = ForestGreenLight,
                    iconTint = ForestGreen,
                    modifier = Modifier.weight(1f)
                )

                MetricCard(
                    title = "Fiado a Receber",
                    value = Formatters.formatCurrency(totalReceivable),
                    subtitle = "${receivableSales.size} compras pendentes",
                    icon = Icons.Default.ReceiptLong,
                    cardColor = AmberLight,
                    iconTint = WarmAmber,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Priority Alerts Section (Estoque Baixo e Contas em Atraso com Juros)
        if (lowStockProducts.isNotEmpty() || overdueSales.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = AlertRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Alertas Prioritários",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    TextButton(onClick = onNavigateToAlerts, modifier = Modifier.testTag("view_all_alerts_button")) {
                        Text("Ver Todos (${lowStockProducts.size + overdueSales.size})", fontSize = 12.sp)
                    }
                }
            }

            // Low Stock Alert Banner
            if (lowStockProducts.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, WarningOrange.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = WarningOrangeLight),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = WarningOrange
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "${lowStockProducts.size} Itens com Estoque Baixo",
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF7C2D12),
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                }

                                Text(
                                    text = "Repor",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = WarningOrange,
                                    modifier = Modifier.clickable { onNavigateToProducts() }
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            lowStockProducts.take(3).forEach { product ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = product.nome,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Código: ${product.codigoBarras} • Categoria: ${product.categoria}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.DarkGray
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "${product.estoqueAtual} / min ${product.estoqueMinimo} ${product.unidadeMedida}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = AlertRed,
                                            modifier = Modifier.padding(end = 8.dp)
                                        )
                                        OutlinedButton(
                                            onClick = { replenishingProduct = product },
                                            modifier = Modifier.height(32.dp),
                                            contentPadding = ButtonDefaults.TextButtonContentPadding
                                        ) {
                                            Text("+ Repor", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Overdue Accounts Alert Banner
            if (overdueSales.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, AlertRed.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = AlertRedLight),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.ErrorOutline,
                                        contentDescription = null,
                                        tint = AlertRed
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "${overdueSales.size} Contas em Atraso (Após Fechamento)",
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF7F1D1D),
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                }
                                Text(
                                    text = "Juros: ${company.jurosMensalPercentual}% a.m.",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AlertRed
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            overdueSales.take(3).forEach { sale ->
                                val calculation = InterestCalculator.calculateOverdueInterest(
                                    valorFinal = sale.valorFinal,
                                    valorPago = sale.valorPago,
                                    dataVencimento = sale.dataVencimento,
                                    jurosMensalPercentual = company.jurosMensalPercentual
                                )

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = sale.clienteNome ?: "Cliente CPF: ${sale.clienteCpf}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Venceu: ${Formatters.formatDate(sale.dataVencimento)} (${calculation.diasAtraso} dias de atraso)",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.DarkGray
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = Formatters.formatCurrency(calculation.valorTotalAtualizado),
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 13.sp,
                                            color = AlertRed
                                        )
                                        Text(
                                            text = "Juros: +${Formatters.formatCurrency(calculation.valorJuros)}",
                                            fontSize = 10.sp,
                                            color = Color(0xFF7F1D1D)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))

                                    Button(
                                        onClick = { selectedSaleForPayment = sale },
                                        modifier = Modifier.height(32.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                                        contentPadding = ButtonDefaults.TextButtonContentPadding
                                    ) {
                                        Text("Receber", fontSize = 11.sp, color = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Quick Navigation Section
        item {
            Text(
                text = "Menu de Gestão",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MenuTile(
                    title = "Produtos &\nEstoque",
                    subtitle = "Cadastro por código",
                    icon = Icons.Default.Inventory2,
                    tint = ForestGreen,
                    onClick = onNavigateToProducts,
                    modifier = Modifier.weight(1f),
                    testTag = "menu_products_tile"
                )

                MenuTile(
                    title = "Clientes &\nFiado",
                    subtitle = "Cadastro por CPF",
                    icon = Icons.Default.People,
                    tint = WarmAmber,
                    onClick = onNavigateToCustomers,
                    modifier = Modifier.weight(1f),
                    testTag = "menu_customers_tile"
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MenuTile(
                    title = "Gráficos &\nRelatórios",
                    subtitle = "Vendas e balanços",
                    icon = Icons.Default.QueryStats,
                    tint = Color(0xFF2563EB),
                    onClick = onNavigateToReports,
                    modifier = Modifier.weight(1f),
                    testTag = "menu_reports_tile"
                )

                MenuTile(
                    title = "Dados da\nEmpresa",
                    subtitle = "Configuração de juros",
                    icon = Icons.Default.Business,
                    tint = Color(0xFF7C3AED),
                    onClick = onNavigateToCompany,
                    modifier = Modifier.weight(1f),
                    testTag = "menu_company_tile"
                )
            }
        }

        // Recent Sales List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Últimas Vendas Realizadas",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (sales.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Nenhuma venda registrada ainda.", color = Color.Gray)
                }
            }
        } else {
            items(sales.take(5)) { sale ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Venda #${sale.id}",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(
                                            when (sale.statusPagamento) {
                                                StatusPagamento.PAGO -> Color(0xFFDCFCE7)
                                                StatusPagamento.ATRASADO -> AlertRedLight
                                                StatusPagamento.PENDENTE -> AmberLight
                                                StatusPagamento.CANCELADO -> Color.LightGray
                                            }
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = sale.statusPagamento.titulo,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when (sale.statusPagamento) {
                                            StatusPagamento.PAGO -> Color(0xFF16A34A)
                                            StatusPagamento.ATRASADO -> AlertRed
                                            StatusPagamento.PENDENTE -> Color(0xFFB45309)
                                            StatusPagamento.CANCELADO -> Color.DarkGray
                                        }
                                    )
                                }
                            }

                            Text(
                                text = "${Formatters.formatDateTime(sale.dataHora)} • ${sale.formaPagamento.titulo}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )

                            if (sale.clienteNome != null) {
                                Text(
                                    text = "Cliente: ${sale.clienteNome}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = Formatters.formatCurrency(sale.valorFinal),
                                fontWeight = FontWeight.ExtraBold,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary
                            )

                            if (sale.statusPagamento == StatusPagamento.PENDENTE || sale.statusPagamento == StatusPagamento.ATRASADO) {
                                Button(
                                    onClick = { selectedSaleForPayment = sale },
                                    modifier = Modifier.height(30.dp),
                                    contentPadding = ButtonDefaults.TextButtonContentPadding,
                                    colors = ButtonDefaults.buttonColors(containerColor = WarmAmber)
                                ) {
                                    Text("Quitar", fontSize = 11.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }

    // Camera Barcode Scanner Dialog
    if (showCameraScanner) {
        BarcodeCameraScannerDialog(
            onBarcodeDetected = { barcode ->
                showCameraScanner = false
                val matched = viewModel.products.value.find { it.codigoBarras == barcode }
                if (matched != null) {
                    scannedProductAlert = matched
                }
            },
            onDismiss = { showCameraScanner = false }
        )
    }

    // Scanned product pop-up
    scannedProductAlert?.let { product ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { scannedProductAlert = null },
            title = { Text(product.nome) },
            text = {
                Column {
                    Text("Código de Barras: ${product.codigoBarras}")
                    Text("Preço: ${Formatters.formatCurrency(product.precoVenda)}")
                    Text("Estoque: ${product.estoqueAtual} ${product.unidadeMedida}")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addToCart(product, 1.0)
                        scannedProductAlert = null
                        onNavigateToPdv()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Adicionar ao PDV")
                }
            },
            dismissButton = {
                TextButton(onClick = { scannedProductAlert = null }) {
                    Text("Fechar")
                }
            }
        )
    }

    // Replenishment dialog
    replenishingProduct?.let { product ->
        var addQty by remember { mutableStateOf("10") }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { replenishingProduct = null },
            title = { Text("Repor Estoque: ${product.nome}") },
            text = {
                Column {
                    Text("Estoque atual: ${product.estoqueAtual} ${product.unidadeMedida}")
                    Spacer(modifier = Modifier.height(8.dp))
                    androidx.compose.material3.OutlinedTextField(
                        value = addQty,
                        onValueChange = { addQty = it },
                        label = { Text("Quantidade a Adicionar (${product.unidadeMedida})") },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val qty = addQty.toDoubleOrNull() ?: 0.0
                        if (qty > 0) {
                            viewModel.replenishStock(product.codigoBarras, qty, "Reposição Rápida")
                        }
                        replenishingProduct = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Confirmar Entrada")
                }
            },
            dismissButton = {
                TextButton(onClick = { replenishingProduct = null }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Payment Dialog for overdue / credit sales
    selectedSaleForPayment?.let { sale ->
        PaymentDialog(
            sale = sale,
            jurosPercentualMensal = company.jurosMensalPercentual,
            onConfirmPayment = { amount, method, notes ->
                viewModel.registerPayment(
                    saleId = sale.id,
                    customerCpf = sale.clienteCpf ?: "",
                    amount = amount,
                    paymentMethod = method,
                    notes = notes
                )
                selectedSaleForPayment = null
            },
            onDismiss = { selectedSaleForPayment = null }
        )
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    cardColor: Color,
    iconTint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = cardColor)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.DarkGray
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF0F172A)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = Color.DarkGray
            )
        }
    }
}

@Composable
fun MenuTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Card(
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(tint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = tint,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = Color.Gray
            )
        }
    }
}
