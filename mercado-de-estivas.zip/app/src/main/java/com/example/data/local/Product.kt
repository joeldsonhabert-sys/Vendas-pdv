package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey
    val codigoBarras: String, // Código de barras como chave primária
    val nome: String,
    val categoria: String = "Estivas Gerais", // Arroz, Feijão, Farinha, Açúcar, Óleos, Cereais, etc.
    val unidadeMedida: String = "UN", // UN, KG, FARDO, PCT, SC (Saco), CX
    val precoCusto: Double,
    val precoVenda: Double,
    val estoqueAtual: Double,
    val estoqueMinimo: Double = 5.0,
    val dataCadastro: Long = System.currentTimeMillis()
)
