package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class TipoMovimentacao(val titulo: String) {
    ENTRADA("Entrada"),
    SAIDA("Saída / Venda"),
    AJUSTE("Ajuste Manual")
}

@Entity(
    tableName = "stock_movements",
    indices = [Index(value = ["produtoCodigoBarras"]), Index(value = ["dataHora"])]
)
data class StockMovement(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val produtoCodigoBarras: String,
    val nomeProduto: String,
    val tipo: TipoMovimentacao,
    val quantidade: Double,
    val estoqueAnterior: Double,
    val estoqueNovo: Double,
    val motivo: String = "",
    val dataHora: Long = System.currentTimeMillis()
)
