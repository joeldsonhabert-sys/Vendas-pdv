package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class FormaPagamento(val titulo: String) {
    DINHEIRO("Dinheiro"),
    PIX("PIX"),
    CARTAO_DEBITO("Cartão de Débito"),
    CARTAO_CREDITO("Cartão de Crédito"),
    A_PRAZO_FIM_MES("Pagar no Fim do Mês (Fiado)")
}

enum class StatusPagamento(val titulo: String) {
    PAGO("Pago"),
    PENDENTE("A Vencer"),
    ATRASADO("Em Atraso"),
    CANCELADO("Cancelado")
}

@Entity(
    tableName = "sales",
    indices = [Index(value = ["clienteCpf"]), Index(value = ["dataHora"])]
)
data class Sale(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dataHora: Long = System.currentTimeMillis(),
    val clienteCpf: String? = null,
    val clienteNome: String? = null,
    val formaPagamento: FormaPagamento,
    val valorTotal: Double,
    val desconto: Double = 0.0,
    val valorFinal: Double,
    val statusPagamento: StatusPagamento = StatusPagamento.PAGO,
    val dataVencimento: Long? = null, // Fechamento do mês da compra
    val assinaturaSvg: String? = null, // Assinatura digital do cliente no recibo
    val reciboEmitido: Boolean = false,
    val jurosAcumulados: Double = 0.0,
    val valorPago: Double = 0.0,
    val dataQuitacao: Long? = null
)
