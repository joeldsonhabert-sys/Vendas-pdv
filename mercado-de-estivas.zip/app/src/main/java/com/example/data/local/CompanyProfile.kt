package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "company_profile")
data class CompanyProfile(
    @PrimaryKey val id: Int = 1,
    val razaoSocial: String = "Mercado de Estivas São José Ltda",
    val nomeFantasia: String = "Estivas & Cereais São José",
    val cnpj: String = "12.345.678/0001-90",
    val telefone: String = "(11) 98765-4321",
    val endereco: String = "Av. do Comércio, 150 - Centro",
    val cidade: String = "São Paulo - SP",
    val jurosMensalPercentual: Double = 2.5, // Percentual de juros inserido pelo financeiro (% ao mês)
    val diaFechamentoMes: Int = 30, // Dia do fechamento do ciclo (fim do mês)
    val mensagemRecibo: String = "Reconheço a dívida referente às mercadorias discriminadas acima para pagamento até o fechamento do ciclo."
)
