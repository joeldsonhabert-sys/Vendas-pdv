package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class Converters {
    @TypeConverter
    fun fromFormaPagamento(value: FormaPagamento): String = value.name

    @TypeConverter
    fun toFormaPagamento(value: String): FormaPagamento = try {
        FormaPagamento.valueOf(value)
    } catch (e: Exception) {
        FormaPagamento.DINHEIRO
    }

    @TypeConverter
    fun fromStatusPagamento(value: StatusPagamento): String = value.name

    @TypeConverter
    fun toStatusPagamento(value: String): StatusPagamento = try {
        StatusPagamento.valueOf(value)
    } catch (e: Exception) {
        StatusPagamento.PAGO
    }

    @TypeConverter
    fun fromTipoMovimentacao(value: TipoMovimentacao): String = value.name

    @TypeConverter
    fun toTipoMovimentacao(value: String): TipoMovimentacao = try {
        TipoMovimentacao.valueOf(value)
    } catch (e: Exception) {
        TipoMovimentacao.ENTRADA
    }
}

@Database(
    entities = [
        CompanyProfile::class,
        Product::class,
        Customer::class,
        Sale::class,
        SaleItem::class,
        PaymentRecord::class,
        StockMovement::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "estivas_mercado_database.db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.appDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: AppDao) {
            // Seed Company Profile
            dao.saveCompanyProfile(
                CompanyProfile(
                    id = 1,
                    razaoSocial = "Mercado de Estivas & Alimentos São Bento Ltda",
                    nomeFantasia = "Mercadinho & Estivas São Bento",
                    cnpj = "23.456.789/0001-12",
                    telefone = "(11) 97123-4567",
                    endereco = "Rua do Mercado, 240 - Centro",
                    cidade = "São Paulo - SP",
                    jurosMensalPercentual = 3.0, // 3% ao mês de juros de mora pós-fechamento
                    diaFechamentoMes = 30
                )
            )

            // Seed typical staple grocery products (Estivas)
            val seedProducts = listOf(
                Product(
                    codigoBarras = "7891000100101",
                    nome = "Arroz Tipo 1 - Pacote 5kg",
                    categoria = "Cereais e Grãos",
                    unidadeMedida = "PCT",
                    precoCusto = 22.50,
                    precoVenda = 29.90,
                    estoqueAtual = 35.0,
                    estoqueMinimo = 10.0
                ),
                Product(
                    codigoBarras = "7891000200202",
                    nome = "Feijão Carioca Nobre 1kg",
                    categoria = "Cereais e Grãos",
                    unidadeMedida = "PCT",
                    precoCusto = 5.20,
                    precoVenda = 7.80,
                    estoqueAtual = 4.0, // Alerta de estoque baixo!
                    estoqueMinimo = 12.0
                ),
                Product(
                    codigoBarras = "7891000300303",
                    nome = "Açúcar Cristal Especial 1kg",
                    categoria = "Estivas Doces",
                    unidadeMedida = "PCT",
                    precoCusto = 3.10,
                    precoVenda = 4.50,
                    estoqueAtual = 2.0, // Alerta de estoque baixo!
                    estoqueMinimo = 15.0
                ),
                Product(
                    codigoBarras = "7891000400404",
                    nome = "Óleo de Soja Refinado 900ml",
                    categoria = "Óleos e Gorduras",
                    unidadeMedida = "UN",
                    precoCusto = 4.80,
                    precoVenda = 6.90,
                    estoqueAtual = 28.0,
                    estoqueMinimo = 10.0
                ),
                Product(
                    codigoBarras = "7891000500505",
                    nome = "Farinha de Trigo Tradicional 1kg",
                    categoria = "Farinhas",
                    unidadeMedida = "PCT",
                    precoCusto = 3.60,
                    precoVenda = 5.20,
                    estoqueAtual = 3.0, // Alerta de estoque baixo!
                    estoqueMinimo = 8.0
                ),
                Product(
                    codigoBarras = "7891000600606",
                    nome = "Café Torrado e Moído 500g",
                    categoria = "Matinais",
                    unidadeMedida = "PCT",
                    precoCusto = 12.50,
                    precoVenda = 16.90,
                    estoqueAtual = 18.0,
                    estoqueMinimo = 6.0
                ),
                Product(
                    codigoBarras = "7891000700707",
                    nome = "Leite Integral UHT 1L",
                    categoria = "Laticínios",
                    unidadeMedida = "CX",
                    precoCusto = 3.90,
                    precoVenda = 5.49,
                    estoqueAtual = 45.0,
                    estoqueMinimo = 12.0
                ),
                Product(
                    codigoBarras = "7891000800808",
                    nome = "Fardo de Farinha de Mandioca (10x1kg)",
                    categoria = "Farinhas",
                    unidadeMedida = "FARDO",
                    precoCusto = 45.00,
                    precoVenda = 62.00,
                    estoqueAtual = 8.0,
                    estoqueMinimo = 5.0
                ),
                Product(
                    codigoBarras = "7891000900909",
                    nome = "Macarrão Espaguete 500g",
                    categoria = "Massas",
                    unidadeMedida = "PCT",
                    precoCusto = 2.40,
                    precoVenda = 3.75,
                    estoqueAtual = 22.0,
                    estoqueMinimo = 10.0
                ),
                Product(
                    codigoBarras = "7891000011223",
                    nome = "Sal Refinado Iodado 1kg",
                    categoria = "Temperos",
                    unidadeMedida = "PCT",
                    precoCusto = 1.20,
                    precoVenda = 2.20,
                    estoqueAtual = 50.0,
                    estoqueMinimo = 15.0
                )
            )
            seedProducts.forEach { dao.insertProduct(it) }

            // Seed Customers (Primary key: CPF)
            val seedCustomers = listOf(
                Customer(
                    cpf = "111.222.333-44",
                    nome = "Antônio Carlos Silva",
                    telefone = "(11) 98111-2233",
                    endereco = "Rua das Palmeiras, 45",
                    limiteCredito = 800.0,
                    observacoes = "Cliente antigo do bairro, paga certinho todo fim de mês."
                ),
                Customer(
                    cpf = "222.333.444-55",
                    nome = "Maria das Dores Santos",
                    telefone = "(11) 98222-3344",
                    endereco = "Travessa Boa Vista, 12",
                    limiteCredito = 600.0,
                    observacoes = "Compras para mercearia de doces caseiros."
                ),
                Customer(
                    cpf = "333.444.555-66",
                    nome = "José Raimundo Souza",
                    telefone = "(11) 98333-4455",
                    endereco = "Av. Principal, 780",
                    limiteCredito = 500.0,
                    observacoes = "Conta em aberto do mês anterior."
                )
            )
            seedCustomers.forEach { dao.insertCustomer(it) }

            // Create initial sales for demo:
            // 1. One paid sale today
            val saleId1 = dao.insertSale(
                Sale(
                    dataHora = System.currentTimeMillis() - 3600000L * 2,
                    clienteCpf = "111.222.333-44",
                    clienteNome = "Antônio Carlos Silva",
                    formaPagamento = FormaPagamento.PIX,
                    valorTotal = 62.19,
                    desconto = 0.0,
                    valorFinal = 62.19,
                    statusPagamento = StatusPagamento.PAGO,
                    valorPago = 62.19,
                    dataQuitacao = System.currentTimeMillis() - 3600000L * 2
                )
            )
            dao.insertSaleItems(
                listOf(
                    SaleItem(vendaId = saleId1, produtoCodigoBarras = "7891000100101", nomeProduto = "Arroz Tipo 1 - Pacote 5kg", quantidade = 1.0, unidadeMedida = "PCT", precoUnitario = 29.90, subtotal = 29.90),
                    SaleItem(vendaId = saleId1, produtoCodigoBarras = "7891000400404", nomeProduto = "Óleo de Soja Refinado 900ml", quantidade = 2.0, unidadeMedida = "UN", precoUnitario = 6.90, subtotal = 13.80),
                    SaleItem(vendaId = saleId1, produtoCodigoBarras = "7891000600606", nomeProduto = "Café Torrado e Moído 500g", quantidade = 1.0, unidadeMedida = "PCT", precoUnitario = 16.90, subtotal = 16.90),
                    SaleItem(vendaId = saleId1, produtoCodigoBarras = "7891000011223", nomeProduto = "Sal Refinado Iodado 1kg", quantidade = 1.0, unidadeMedida = "PCT", precoUnitario = 2.20, subtotal = 2.20)
                )
            )

            // 2. One overdue sale from previous month to trigger the overdue interest alert!
            val oneMonthAgo = System.currentTimeMillis() - (86400000L * 45) // 45 days ago
            val dueOneMonthAgo = System.currentTimeMillis() - (86400000L * 15) // due 15 days ago
            val saleId2 = dao.insertSale(
                Sale(
                    dataHora = oneMonthAgo,
                    clienteCpf = "333.444.555-66",
                    clienteNome = "José Raimundo Souza",
                    formaPagamento = FormaPagamento.A_PRAZO_FIM_MES,
                    valorTotal = 185.50,
                    desconto = 0.0,
                    valorFinal = 185.50,
                    statusPagamento = StatusPagamento.ATRASADO,
                    dataVencimento = dueOneMonthAgo,
                    reciboEmitido = true,
                    jurosAcumulados = 5.56,
                    valorPago = 0.0
                )
            )
            dao.insertSaleItems(
                listOf(
                    SaleItem(vendaId = saleId2, produtoCodigoBarras = "7891000800808", nomeProduto = "Fardo de Farinha de Mandioca (10x1kg)", quantidade = 2.0, unidadeMedida = "FARDO", precoUnitario = 62.00, subtotal = 124.00),
                    SaleItem(vendaId = saleId2, produtoCodigoBarras = "7891000100101", nomeProduto = "Arroz Tipo 1 - Pacote 5kg", quantidade = 2.0, unidadeMedida = "PCT", precoUnitario = 29.90, subtotal = 59.80)
                )
            )

            // 3. One active pending sale for current month closing
            val currentMonthDue = System.currentTimeMillis() + (86400000L * 10)
            val saleId3 = dao.insertSale(
                Sale(
                    dataHora = System.currentTimeMillis() - (86400000L * 3),
                    clienteCpf = "111.222.333-44",
                    clienteNome = "Antônio Carlos Silva",
                    formaPagamento = FormaPagamento.A_PRAZO_FIM_MES,
                    valorTotal = 94.20,
                    desconto = 0.0,
                    valorFinal = 94.20,
                    statusPagamento = StatusPagamento.PENDENTE,
                    dataVencimento = currentMonthDue,
                    reciboEmitido = true,
                    jurosAcumulados = 0.0,
                    valorPago = 0.0
                )
            )
            dao.insertSaleItems(
                listOf(
                    SaleItem(vendaId = saleId3, produtoCodigoBarras = "7891000100101", nomeProduto = "Arroz Tipo 1 - Pacote 5kg", quantidade = 2.0, unidadeMedida = "PCT", precoUnitario = 29.90, subtotal = 59.80),
                    SaleItem(vendaId = saleId3, produtoCodigoBarras = "7891000700707", nomeProduto = "Leite Integral UHT 1L", quantidade = 6.0, unidadeMedida = "CX", precoUnitario = 5.49, subtotal = 32.94)
                )
            )
        }
    }
}
