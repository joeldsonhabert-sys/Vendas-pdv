package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey
    val cpf: String, // CPF como chave primária
    val nome: String,
    val telefone: String = "",
    val endereco: String = "",
    val limiteCredito: Double = 1000.0,
    val observacoes: String = "",
    val dataCadastro: Long = System.currentTimeMillis()
)
