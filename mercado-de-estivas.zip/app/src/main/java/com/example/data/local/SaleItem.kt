package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "sale_items",
    foreignKeys = [
        ForeignKey(
            entity = Sale::class,
            parentColumns = ["id"],
            childColumns = ["vendaId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["vendaId"]), Index(value = ["produtoCodigoBarras"])]
)
data class SaleItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val vendaId: Long,
    val produtoCodigoBarras: String,
    val nomeProduto: String,
    val quantidade: Double,
    val unidadeMedida: String = "UN",
    val precoUnitario: Double,
    val subtotal: Double
)
