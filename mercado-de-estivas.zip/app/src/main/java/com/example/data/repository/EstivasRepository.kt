package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.local.CompanyProfile
import com.example.data.local.Customer
import com.example.data.local.FormaPagamento
import com.example.data.local.PaymentRecord
import com.example.data.local.Product
import com.example.data.local.Sale
import com.example.data.local.SaleItem
import com.example.data.local.SaleWithItems
import com.example.data.local.StatusPagamento
import com.example.data.local.StockMovement
import com.example.data.local.TipoMovimentacao
import com.example.util.InterestCalculator
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

data class CartItem(
    val product: Product,
    val quantity: Double,
    val customPrice: Double? = null
) {
    val unitPrice: Double get() = customPrice ?: product.precoVenda
    val subtotal: Double get() = unitPrice * quantity
}

class EstivasRepository(private val appDao: AppDao) {

    val companyProfileFlow: Flow<CompanyProfile?> = appDao.getCompanyProfileFlow()
    val allProducts: Flow<List<Product>> = appDao.getAllProducts()
    val lowStockProducts: Flow<List<Product>> = appDao.getLowStockProducts()
    val lowStockCount: Flow<Int> = appDao.getLowStockCountFlow()

    val allCustomers: Flow<List<Customer>> = appDao.getAllCustomers()
    val allSales: Flow<List<Sale>> = appDao.getAllSales()
    val receivableSales: Flow<List<Sale>> = appDao.getReceivableSales()
    val overdueSales: Flow<List<Sale>> = appDao.getOverdueSales()
    val overdueCount: Flow<Int> = appDao.getOverdueCountFlow()
    val recentStockMovements: Flow<List<StockMovement>> = appDao.getRecentStockMovements()

    suspend fun getCompanyProfile(): CompanyProfile {
        return appDao.getCompanyProfile() ?: CompanyProfile()
    }

    suspend fun saveCompanyProfile(profile: CompanyProfile) {
        appDao.saveCompanyProfile(profile)
    }

    // --- Products ---
    suspend fun getProductByBarcode(barcode: String): Product? {
        return appDao.getProductByBarcode(barcode.trim())
    }

    fun getProductByBarcodeFlow(barcode: String): Flow<Product?> {
        return appDao.getProductByBarcodeFlow(barcode.trim())
    }

    suspend fun saveProduct(product: Product, isNew: Boolean = false) {
        val existing = appDao.getProductByBarcode(product.codigoBarras)
        if (existing == null || isNew) {
            appDao.insertProduct(product)
            appDao.insertStockMovement(
                StockMovement(
                    produtoCodigoBarras = product.codigoBarras,
                    nomeProduto = product.nome,
                    tipo = TipoMovimentacao.ENTRADA,
                    quantidade = product.estoqueAtual,
                    estoqueAnterior = 0.0,
                    estoqueNovo = product.estoqueAtual,
                    motivo = "Cadastro Inicial de Produto"
                )
            )
        } else {
            appDao.updateProduct(product)
            if (existing.estoqueAtual != product.estoqueAtual) {
                appDao.insertStockMovement(
                    StockMovement(
                        produtoCodigoBarras = product.codigoBarras,
                        nomeProduto = product.nome,
                        tipo = TipoMovimentacao.AJUSTE,
                        quantidade = product.estoqueAtual - existing.estoqueAtual,
                        estoqueAnterior = existing.estoqueAtual,
                        estoqueNovo = product.estoqueAtual,
                        motivo = "Ajuste de Estoque Manual"
                    )
                )
            }
        }
    }

    suspend fun deleteProduct(barcode: String) {
        appDao.deleteProduct(barcode)
    }

    suspend fun addStockToProduct(barcode: String, additionalQuantity: Double, motivo: String = "Reposição de Estoque") {
        val product = appDao.getProductByBarcode(barcode) ?: return
        val newStock = product.estoqueAtual + additionalQuantity
        appDao.updateStock(barcode, newStock)
        appDao.insertStockMovement(
            StockMovement(
                produtoCodigoBarras = barcode,
                nomeProduto = product.nome,
                tipo = TipoMovimentacao.ENTRADA,
                quantidade = additionalQuantity,
                estoqueAnterior = product.estoqueAtual,
                estoqueNovo = newStock,
                motivo = motivo
            )
        )
    }

    // --- Customers ---
    suspend fun getCustomerByCpf(cpf: String): Customer? {
        return appDao.getCustomerByCpf(cpf.trim())
    }

    fun searchCustomers(query: String): Flow<List<Customer>> {
        return appDao.searchCustomers(query.trim())
    }

    suspend fun saveCustomer(customer: Customer) {
        val existing = appDao.getCustomerByCpf(customer.cpf)
        if (existing == null) {
            appDao.insertCustomer(customer)
        } else {
            appDao.updateCustomer(customer)
        }
    }

    suspend fun deleteCustomer(cpf: String) {
        appDao.deleteCustomer(cpf)
    }

    fun getSalesByCustomer(cpf: String): Flow<List<Sale>> {
        return appDao.getSalesByCustomer(cpf)
    }

    fun getPaymentsForCustomer(cpf: String): Flow<List<PaymentRecord>> {
        return appDao.getPaymentsForCustomer(cpf)
    }

    // --- Sales & PDV ---
    suspend fun getSaleWithItems(saleId: Long): SaleWithItems? {
        return appDao.getSaleWithItems(saleId)
    }

    suspend fun registerSale(
        items: List<CartItem>,
        customer: Customer?,
        formaPagamento: FormaPagamento,
        desconto: Double = 0.0,
        signatureSvg: String? = null
    ): Long {
        val company = getCompanyProfile()
        val totalBruto = items.sumOf { it.subtotal }
        val valorFinal = maxOf(0.0, totalBruto - desconto)

        val isCreditFimMes = formaPagamento == FormaPagamento.A_PRAZO_FIM_MES
        val now = System.currentTimeMillis()
        val vencimento = if (isCreditFimMes) {
            InterestCalculator.calculateEndOfMonthDueDate(now, company.diaFechamentoMes)
        } else null

        val sale = Sale(
            dataHora = now,
            clienteCpf = customer?.cpf,
            clienteNome = customer?.nome,
            formaPagamento = formaPagamento,
            valorTotal = totalBruto,
            desconto = desconto,
            valorFinal = valorFinal,
            statusPagamento = if (isCreditFimMes) StatusPagamento.PENDENTE else StatusPagamento.PAGO,
            dataVencimento = vencimento,
            assinaturaSvg = signatureSvg,
            reciboEmitido = isCreditFimMes,
            jurosAcumulados = 0.0,
            valorPago = if (isCreditFimMes) 0.0 else valorFinal,
            dataQuitacao = if (isCreditFimMes) null else now
        )

        val saleId = appDao.insertSale(sale)

        // Save items and deduct stock
        val saleItems = items.map { cartItem ->
            SaleItem(
                vendaId = saleId,
                produtoCodigoBarras = cartItem.product.codigoBarras,
                nomeProduto = cartItem.product.nome,
                quantidade = cartItem.quantity,
                unidadeMedida = cartItem.product.unidadeMedida,
                precoUnitario = cartItem.unitPrice,
                subtotal = cartItem.subtotal
            )
        }
        appDao.insertSaleItems(saleItems)

        // Update stock for each product
        for (cartItem in items) {
            val currentProduct = appDao.getProductByBarcode(cartItem.product.codigoBarras)
            if (currentProduct != null) {
                val newStock = currentProduct.estoqueAtual - cartItem.quantity
                appDao.updateStock(currentProduct.codigoBarras, newStock)
                appDao.insertStockMovement(
                    StockMovement(
                        produtoCodigoBarras = currentProduct.codigoBarras,
                        nomeProduto = currentProduct.nome,
                        tipo = TipoMovimentacao.SAIDA,
                        quantidade = cartItem.quantity,
                        estoqueAnterior = currentProduct.estoqueAtual,
                        estoqueNovo = newStock,
                        motivo = "Venda PDV #$saleId"
                    )
                )
            }
        }

        return saleId
    }

    // --- Payment / Quitar Fiado ---
    suspend fun registerPayment(
        saleId: Long,
        customerCpf: String,
        amountPaid: Double,
        formaPagamento: FormaPagamento = FormaPagamento.DINHEIRO,
        observacao: String = ""
    ): Boolean {
        val sale = appDao.getSaleById(saleId) ?: return false
        val company = getCompanyProfile()

        val calculation = InterestCalculator.calculateOverdueInterest(
            valorFinal = sale.valorFinal,
            valorPago = sale.valorPago,
            dataVencimento = sale.dataVencimento,
            jurosMensalPercentual = company.jurosMensalPercentual
        )

        val newTotalPaid = sale.valorPago + amountPaid
        val totalComJuros = sale.valorFinal + calculation.valorJuros
        val isFullyPaid = newTotalPaid >= (totalComJuros - 0.05)

        val updatedSale = sale.copy(
            valorPago = newTotalPaid,
            jurosAcumulados = calculation.valorJuros,
            statusPagamento = if (isFullyPaid) StatusPagamento.PAGO else if (calculation.estaEmAtraso) StatusPagamento.ATRASADO else StatusPagamento.PENDENTE,
            dataQuitacao = if (isFullyPaid) System.currentTimeMillis() else null
        )
        appDao.updateSale(updatedSale)

        appDao.insertPaymentRecord(
            PaymentRecord(
                vendaId = saleId,
                clienteCpf = customerCpf,
                valorPrincipal = minOf(amountPaid, calculation.saldoDevedorBase),
                valorJuros = maxOf(0.0, amountPaid - calculation.saldoDevedorBase),
                valorTotalPago = amountPaid,
                formaPagamento = formaPagamento,
                observacao = observacao
            )
        )

        return isFullyPaid
    }

    suspend fun syncAllOverdueStatus() {
        val company = getCompanyProfile()
        val receivables = appDao.getReceivableSales().firstOrNull() ?: return
        val now = System.currentTimeMillis()

        for (sale in receivables) {
            val calc = InterestCalculator.calculateOverdueInterest(
                valorFinal = sale.valorFinal,
                valorPago = sale.valorPago,
                dataVencimento = sale.dataVencimento,
                jurosMensalPercentual = company.jurosMensalPercentual,
                currentTimestamp = now
            )

            if (calc.estaEmAtraso && sale.statusPagamento != StatusPagamento.ATRASADO) {
                appDao.updateSale(
                    sale.copy(
                        statusPagamento = StatusPagamento.ATRASADO,
                        jurosAcumulados = calc.valorJuros
                    )
                )
            } else if (calc.estaEmAtraso && sale.jurosAcumulados != calc.valorJuros) {
                appDao.updateSale(
                    sale.copy(
                        jurosAcumulados = calc.valorJuros
                    )
                )
            }
        }
    }
}
