package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "payment_records",
    foreignKeys = [
        ForeignKey(
            entity = Sale::class,
            parentColumns = ["id"],
            childColumns = ["vendaId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["vendaId"]), Index(value = ["clienteCpf"])]
)
data class PaymentRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val vendaId: Long,
    val clienteCpf: String,
    val valorPrincipal: Double,
    val valorJuros: Double = 0.0,
    val valorTotalPago: Double,
    val formaPagamento: FormaPagamento = FormaPagamento.DINHEIRO,
    val dataPagamento: Long = System.currentTimeMillis(),
    val observacao: String = ""
)
