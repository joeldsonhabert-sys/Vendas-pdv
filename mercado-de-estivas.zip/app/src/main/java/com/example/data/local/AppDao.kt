package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

data class SaleWithItems(
    @androidx.room.Embedded val sale: Sale,
    @androidx.room.Relation(
        parentColumn = "id",
        entityColumn = "vendaId"
    )
    val items: List<SaleItem>
)

@Dao
interface AppDao {

    // --- COMPANY ---
    @Query("SELECT * FROM company_profile WHERE id = 1 LIMIT 1")
    fun getCompanyProfileFlow(): Flow<CompanyProfile?>

    @Query("SELECT * FROM company_profile WHERE id = 1 LIMIT 1")
    suspend fun getCompanyProfile(): CompanyProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveCompanyProfile(profile: CompanyProfile)

    // --- PRODUCTS (Primary key: codigoBarras) ---
    @Query("SELECT * FROM products ORDER BY nome ASC")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE codigoBarras = :barcode LIMIT 1")
    suspend fun getProductByBarcode(barcode: String): Product?

    @Query("SELECT * FROM products WHERE codigoBarras = :barcode LIMIT 1")
    fun getProductByBarcodeFlow(barcode: String): Flow<Product?>

    @Query("SELECT * FROM products WHERE estoqueAtual <= estoqueMinimo ORDER BY estoqueAtual ASC")
    fun getLowStockProducts(): Flow<List<Product>>

    @Query("SELECT COUNT(*) FROM products WHERE estoqueAtual <= estoqueMinimo")
    fun getLowStockCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product)

    @Update
    suspend fun updateProduct(product: Product)

    @Query("DELETE FROM products WHERE codigoBarras = :barcode")
    suspend fun deleteProduct(barcode: String)

    @Query("UPDATE products SET estoqueAtual = :newStock WHERE codigoBarras = :barcode")
    suspend fun updateStock(barcode: String, newStock: Double)

    // --- CUSTOMERS (Primary key: cpf) ---
    @Query("SELECT * FROM customers ORDER BY nome ASC")
    fun getAllCustomers(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE cpf = :cpf LIMIT 1")
    suspend fun getCustomerByCpf(cpf: String): Customer?

    @Query("SELECT * FROM customers WHERE cpf = :cpf LIMIT 1")
    fun getCustomerByCpfFlow(cpf: String): Flow<Customer?>

    @Query("SELECT * FROM customers WHERE nome LIKE '%' || :query || '%' OR cpf LIKE '%' || :query || '%'")
    fun searchCustomers(query: String): Flow<List<Customer>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: Customer)

    @Update
    suspend fun updateCustomer(customer: Customer)

    @Query("DELETE FROM customers WHERE cpf = :cpf")
    suspend fun deleteCustomer(cpf: String)

    // --- SALES ---
    @Query("SELECT * FROM sales ORDER BY dataHora DESC")
    fun getAllSales(): Flow<List<Sale>>

    @Query("SELECT * FROM sales WHERE id = :id LIMIT 1")
    suspend fun getSaleById(id: Long): Sale?

    @Transaction
    @Query("SELECT * FROM sales WHERE id = :id LIMIT 1")
    suspend fun getSaleWithItems(id: Long): SaleWithItems?

    @Query("SELECT * FROM sales WHERE clienteCpf = :cpf ORDER BY dataHora DESC")
    fun getSalesByCustomer(cpf: String): Flow<List<Sale>>

    @Query("SELECT * FROM sales WHERE statusPagamento IN ('PENDENTE', 'ATRASADO') ORDER BY dataVencimento ASC")
    fun getReceivableSales(): Flow<List<Sale>>

    @Query("SELECT * FROM sales WHERE statusPagamento = 'ATRASADO' ORDER BY dataVencimento ASC")
    fun getOverdueSales(): Flow<List<Sale>>

    @Query("SELECT COUNT(*) FROM sales WHERE statusPagamento = 'ATRASADO'")
    fun getOverdueCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSale(sale: Sale): Long

    @Update
    suspend fun updateSale(sale: Sale)

    // --- SALE ITEMS ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSaleItems(items: List<SaleItem>)

    @Query("SELECT * FROM sale_items WHERE vendaId = :saleId")
    suspend fun getItemsForSale(saleId: Long): List<SaleItem>

    // --- PAYMENTS ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPaymentRecord(record: PaymentRecord): Long

    @Query("SELECT * FROM payment_records WHERE vendaId = :saleId ORDER BY dataPagamento DESC")
    fun getPaymentsForSale(saleId: Long): Flow<List<PaymentRecord>>

    @Query("SELECT * FROM payment_records WHERE clienteCpf = :cpf ORDER BY dataPagamento DESC")
    fun getPaymentsForCustomer(cpf: String): Flow<List<PaymentRecord>>

    // --- STOCK MOVEMENTS ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockMovement(movement: StockMovement)

    @Query("SELECT * FROM stock_movements ORDER BY dataHora DESC LIMIT 50")
    fun getRecentStockMovements(): Flow<List<StockMovement>>
}
