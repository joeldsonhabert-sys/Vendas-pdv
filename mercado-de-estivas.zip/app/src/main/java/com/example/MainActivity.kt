package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.PointOfSale
import androidx.compose.material.icons.outlined.QueryStats
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.EstivasViewModel
import com.example.ui.EstivasViewModelFactory
import com.example.ui.screens.AlertsScreen
import com.example.ui.screens.CompanySettingsScreen
import com.example.ui.screens.CustomersScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PdvScreen
import com.example.ui.screens.ProductsScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.WarmAmber

enum class AppDestination(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String
) {
    HOME("Início", Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
    PDV("Vender", Icons.Filled.PointOfSale, Icons.Outlined.PointOfSale, "nav_pdv"),
    PRODUCTS("Estoque", Icons.Filled.Inventory2, Icons.Outlined.Inventory2, "nav_products"),
    CUSTOMERS("Clientes", Icons.Filled.People, Icons.Outlined.People, "nav_customers"),
    ALERTS("Alertas", Icons.Filled.Notifications, Icons.Outlined.Notifications, "nav_alerts"),
    REPORTS("Gráficos", Icons.Filled.QueryStats, Icons.Outlined.QueryStats, "nav_reports"),
    COMPANY("Empresa", Icons.Filled.Business, Icons.Filled.Business, "nav_company")
}

class MainActivity : ComponentActivity() {

    private val viewModel: EstivasViewModel by viewModels {
        val app = application as EstivasApplication
        EstivasViewModelFactory(app.repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: EstivasViewModel) {
    var currentDestination by remember { mutableStateOf(AppDestination.HOME) }
    val company by viewModel.companyProfile.collectAsStateWithLifecycle()
    val lowStockCount by viewModel.lowStockCount.collectAsStateWithLifecycle()
    val overdueCount by viewModel.overdueCount.collectAsStateWithLifecycle()
    val totalAlerts = lowStockCount + overdueCount

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = when (currentDestination) {
                            AppDestination.HOME -> company.nomeFantasia.ifBlank { "Mercado de Estivas" }
                            AppDestination.PDV -> "Ponto de Venda (PDV)"
                            AppDestination.PRODUCTS -> "Produtos & Estoque"
                            AppDestination.CUSTOMERS -> "Clientes & Vendas a Prazo"
                            AppDestination.ALERTS -> "Painel de Alertas"
                            AppDestination.REPORTS -> "Gráficos & Balanço"
                            AppDestination.COMPANY -> "Cadastro da Empresa & Juros"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.primary
                ),
                actions = {
                    if (currentDestination != AppDestination.ALERTS) {
                        IconButton(
                            onClick = { currentDestination = AppDestination.ALERTS },
                            modifier = Modifier.testTag("top_bar_alerts_button")
                        ) {
                            BadgedBox(
                                badge = {
                                    if (totalAlerts > 0) {
                                        Badge(
                                            containerColor = AlertRed,
                                            contentColor = Color.White
                                        ) {
                                            Text("$totalAlerts")
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Notifications,
                                    contentDescription = "Alertas",
                                    tint = if (totalAlerts > 0) AlertRed else Color.Gray
                                )
                            }
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                listOf(
                    AppDestination.HOME,
                    AppDestination.PDV,
                    AppDestination.PRODUCTS,
                    AppDestination.CUSTOMERS,
                    AppDestination.ALERTS,
                    AppDestination.REPORTS
                ).forEach { destination ->
                    val selected = currentDestination == destination

                    NavigationBarItem(
                        selected = selected,
                        onClick = { currentDestination = destination },
                        icon = {
                            if (destination == AppDestination.ALERTS && totalAlerts > 0) {
                                BadgedBox(
                                    badge = {
                                        Badge(containerColor = AlertRed, contentColor = Color.White) {
                                            Text("$totalAlerts")
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (selected) destination.selectedIcon else destination.unselectedIcon,
                                        contentDescription = destination.title
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = if (selected) destination.selectedIcon else destination.unselectedIcon,
                                    contentDescription = destination.title
                                )
                            }
                        },
                        label = {
                            Text(
                                text = destination.title,
                                fontSize = 11.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ForestGreen,
                            selectedTextColor = ForestGreen,
                            indicatorColor = ForestGreen.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag(destination.tag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentDestination) {
                AppDestination.HOME -> HomeScreen(
                    viewModel = viewModel,
                    onNavigateToPdv = { currentDestination = AppDestination.PDV },
                    onNavigateToProducts = { currentDestination = AppDestination.PRODUCTS },
                    onNavigateToCustomers = { currentDestination = AppDestination.CUSTOMERS },
                    onNavigateToAlerts = { currentDestination = AppDestination.ALERTS },
                    onNavigateToReports = { currentDestination = AppDestination.REPORTS },
                    onNavigateToCompany = { currentDestination = AppDestination.COMPANY }
                )
                AppDestination.PDV -> PdvScreen(
                    viewModel = viewModel,
                    onSaleFinished = { currentDestination = AppDestination.HOME }
                )
                AppDestination.PRODUCTS -> ProductsScreen(
                    viewModel = viewModel
                )
                AppDestination.CUSTOMERS -> CustomersScreen(
                    viewModel = viewModel
                )
                AppDestination.ALERTS -> AlertsScreen(
                    viewModel = viewModel
                )
                AppDestination.REPORTS -> ReportsScreen(
                    viewModel = viewModel
                )
                AppDestination.COMPANY -> CompanySettingsScreen(
                    viewModel = viewModel
                )
            }
        }
    }
}
